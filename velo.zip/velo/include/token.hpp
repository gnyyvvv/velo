#pragma once
#include <string>

namespace velo {

// Token turlari - Python sintaksisi uchun
enum class TokType {
    // Literallar
    INT,        // 123
    FLOAT,      // 3.14
    STR,        // "salom"
    FSTR,       // f"salom {ism}"
    ID,         // o'zgaruvchi nomi

    // Kalit so'zlar (KEYWORDS)
    KW,         // def, if, else, while...

    // Operatorlar
    OP,         // +, -, *, /, ==...

    // Struktura
    NEWLINE,    // \n (qator oxiri)
    INDENT,     // blok boshlandi (bo'sh joy ko'paydi)
    DEDENT,     // blok tugadi (bo'sh joy kamaydi)
    EOF_        // fayl tugadi
};

struct Token {
    TokType type;
    std::string text;
    long long   i = 0;
    double      f = 0.0;
    int line = 1, col = 1;

    Token() = default;
    Token(TokType t, std::string s, int l, int c)
        : type(t), text(std::move(s)), line(l), col(c) {}
};

} // namespace velo
#pragma once
#include "ast.hpp"
#include "../vertox/include/opcode.hpp"
#include "../vertox/include/value.hpp"
#include <vector>
#include <unordered_map>

namespace velo {

// Kompilyatsiya natijasi
struct CompiledCode {
    std::vector<vertox::Instr> code;
    std::vector<vertox::ValuePtr> consts;
};

class Compiler {
public:
    Compiler();

    // Asosiy metod: AST -> bytecode
    CompiledCode compile(Node* program);

private:
    std::vector<vertox::Instr> code_;
    std::vector<vertox::ValuePtr> consts_;

    std::unordered_map<std::string, int> nameCache_;
    bool inFunction_ = false;

    // ===== Yordamchi =====
    int constIdx(vertox::ValuePtr v);
    int nameIdx(const std::string& name);
    void emit(vertox::Op op, int64_t arg = 0);
    int here() const { return (int)code_.size(); }
    void patch(int pos, int target);

    // ===== Ko'rsatmalar =====
    void visit(Node* n);
    void visitProgram(Program* n);
    void visitBlock(Block* n);
    void visitFnDef(FnDef* n);
    void visitIf(If* n);
    void visitWhile(While* n);
    void visitFor(For* n);
    void visitReturn(Return* n);
    void visitAssign(Assign* n);
    void visitAugAssign(AugAssign* n);
    void visitBreak(Break* n);
    void visitContinue(Continue* n);
    void visitPass(Pass* n);

    // ===== Ifodalar =====
    void expr(Node* n);
    void exprNum(Num* n);
    void exprStr(Str* n);
    void exprFStr(FStr* n);
    void exprBool(Bool* n);
    void exprNull(Null* n);
    void exprVar(Var* n);
    void exprBinOp(BinOp* n);
    void exprUnOp(UnOp* n);
    void exprCompare(Compare* n);
    void exprCall(Call* n);
    void exprList(ListLit* n);
    void exprTuple(TupleLit* n);
    void exprDict(DictLit* n);
    void exprIndex(Index* n);
    void exprLambda(Lambda* n);
    void exprAttribute(Attribute* n);    // ? YANGI - qo'shildi

    // Loop stack
    struct LoopCtx {
        std::vector<int> breakPatches;
        std::vector<int> continuePatches;
    };
    std::vector<LoopCtx> loopStack_;
};

} // namespace velo
#pragma once
#include <memory>
#include <string>
#include <vector>

namespace velo {

// Barcha AST tugunlarining asosi
struct Node {
    virtual ~Node() = default;
};

using NodePtr = std::unique_ptr<Node>;

// ============================================================
// LITERALLAR
// ============================================================

// Son: 123 yoki 3.14
struct Num : Node {
    long long i = 0;
    double f = 0.0;
    bool isFloat = false;
};

// String: "salom"
struct Str : Node {
    std::string value;
};

// f-string: f"salom {ism}"
struct FStr : Node {
    std::string value;    // hozircha oddiy string sifatida
};

// Boolean: True / False
struct Bool : Node {
    bool value;
};

// None
struct Null : Node {};

// ============================================================
// IDENTIFIKATORLAR VA OPERATSIYALAR
// ============================================================

// O'zgaruvchi: x, ism, sonlar
struct Var : Node {
    std::string name;
};

// Binary operator: a + b, a == b, a and b
struct BinOp : Node {
    std::string op;
    NodePtr left;
    NodePtr right;
};

// Unary operator: -a, not a
struct UnOp : Node {
    std::string op;
    NodePtr operand;
};

// Taqqoslash zanjiri: a < b < c
struct Compare : Node {
    NodePtr left;
    std::vector<std::pair<std::string, NodePtr>> ops;  // [("<", b), ("<", c)]
};

// ============================================================
// TAYINLASH
// ============================================================

// x = 5
struct Assign : Node {
    NodePtr target;      // Var yoki Index
    NodePtr value;
};

// x += 5 (qisqartirilgan)
struct AugAssign : Node {
    NodePtr target;
    std::string op;      // +=, -=, *=, /=
    NodePtr value;
};

// ============================================================
// TO'PLAMLAR
// ============================================================

// [1, 2, 3]
struct ListLit : Node {
    std::vector<NodePtr> items;
};

// (1, 2, 3)
struct TupleLit : Node {
    std::vector<NodePtr> items;
};

// {"a": 1, "b": 2}
struct DictLit : Node {
    std::vector<std::pair<NodePtr, NodePtr>> items;
};

// ro'yxatdan element olish: lst[0]
struct Index : Node {
    NodePtr obj;
    NodePtr index;
};

// x.attr
struct Attribute : Node {
    NodePtr obj;
    std::string attr;
};

// ============================================================
// BOSHqARUV
// ============================================================

// if cond: then else: els
struct If : Node {
    NodePtr cond;
    NodePtr then_body;
    NodePtr else_body;   // nullptr bo'lishi mumkin
};

// while cond: body
struct While : Node {
    NodePtr cond;
    NodePtr body;
};

// for target in iter: body
struct For : Node {
    std::string target;
    NodePtr iter;
    NodePtr body;
};

// break / continue
struct Break : Node {};
struct Continue : Node {};
struct Pass : Node {};

// return expr
struct Return : Node {
    NodePtr value;   // nullptr bo'lishi mumkin
};

// ============================================================
// FUNKSIYALAR VA KLASSLAR
// ============================================================

// def nom(params): body
struct FnDef : Node {
    std::string name;
    std::vector<std::string> params;
    std::vector<NodePtr> defaults;   // default qiymatlar
    NodePtr body;
};

// lambda x: x + 1
struct Lambda : Node {
    std::vector<std::string> params;
    NodePtr body;
};

// f(args)
struct Call : Node {
    NodePtr fn;
    std::vector<NodePtr> args;
    std::vector<std::pair<std::string, NodePtr>> kwargs;  // kalitli argumentlar
};

// class Nom(Base): body
struct ClassDef : Node {
    std::string name;
    std::vector<std::string> bases;
    NodePtr body;
};

// ============================================================
// XATOLARNI USHLASH
// ============================================================

// try: ... except E as e: ...
struct Try : Node {
    NodePtr try_body;
    std::vector<std::tuple<std::string, std::string, NodePtr>> handlers;
    NodePtr else_body;
    NodePtr finally_body;
};

// raise X
struct Raise : Node {
    NodePtr exc;
};

// ============================================================
// MODULLAR
// ============================================================

// import math
struct Import : Node {
    std::vector<std::string> names;
};

// from math import sqrt
struct FromImport : Node {
    std::string module;
    std::vector<std::string> names;
};

// ============================================================
// BLOK VA DASTUR
// ============================================================

// Bir nechta ko'rsatmalar
struct Block : Node {
    std::vector<NodePtr> statements;
};

// Butun dastur
struct Program : Node {
    std::vector<NodePtr> statements;
};

} // namespace velo
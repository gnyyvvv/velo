#pragma once
#include "token.hpp"
#include <vector>
#include <string>

namespace velo {

class Lexer {
public:
    explicit Lexer(std::string src) : src_(std::move(src)) {}
    std::vector<Token> tokenize();

private:
    std::string src_;
    size_t i_ = 0;
    int line_ = 1, col_ = 1;

    // Indentatsiya uchun stack (Python kabi)
    std::vector<int> indentStack_;
    bool atLineStart_ = true;
    int bracketDepth_ = 0;   // () [] {} ichida NEWLINE/INDENT yo'q

    char peek(int k = 0) const {
        size_t j = i_ + k;
        return j < src_.size() ? src_[j] : '\0';
    }

    char adv() {
        char c = src_[i_++];
        if (c == '\n') { line_++; col_ = 1; }
        else col_++;
        return c;
    }

    void handleIndent(std::vector<Token>& out, int currentIndent);
};

} // namespace velo
#pragma once
#include "token.hpp"
#include "ast.hpp"
#include <vector>

namespace velo {

class Parser {
public:
    explicit Parser(std::vector<Token> tokens);

    // Asosiy metod
    NodePtr parseProgram();

private:
    std::vector<Token> toks_;
    size_t pos_ = 0;

    // ===== Yordamchi =====
    const Token& peek(int k = 0) const;
    const Token& prev() const;
    bool isAtEnd() const;
    bool check(TokType type, const std::string& text = "") const;
    bool checkKw(const std::string& kw) const;
    bool checkOp(const std::string& op) const;
    bool match(TokType type, const std::string& text = "");
    bool matchKw(const std::string& kw);
    bool matchOp(const std::string& op);
    const Token& advance();
    const Token& expect(TokType type, const std::string& err = "");
    const Token& expectOp(const std::string& op);
    const Token& expectKw(const std::string& kw);
    void skipNewlines();
    void expectNewline();
    void expectColon();

    // ===== Ko'rsatmalar (statements) =====
    NodePtr statement();
    NodePtr simpleStatement();
    NodePtr compoundStatement();
    NodePtr ifStatement();
    NodePtr whileStatement();
    NodePtr forStatement();
    NodePtr defStatement();
    NodePtr returnStatement();
    NodePtr breakStatement();
    NodePtr continueStatement();
    NodePtr passStatement();
    NodePtr importStatement();
    NodePtr fromImportStatement();
    NodePtr classStatement();
    NodePtr block();                // INDENT ... DEDENT

    // ===== Ifodalar (expressions) =====
    NodePtr expression();
    NodePtr assignment();
    NodePtr ternary();
    NodePtr orExpr();
    NodePtr andExpr();
    NodePtr notExpr();
    NodePtr comparison();
    NodePtr arith();
    NodePtr term();
    NodePtr factor();
    NodePtr unary();
    NodePtr power();
    NodePtr postfix();
    NodePtr atom();

    // ===== Qo'shimcha =====
    NodePtr parseArgs(NodePtr fn);   // chaqiruv argumentlari
    std::vector<std::string> parseParamList();
};

} // namespace velo
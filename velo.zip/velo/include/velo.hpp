#pragma once
#include <string>

namespace velo {

// Yuqori daraja API
class Velo {
public:
    // Manba kodini ishga tushirish
    static int run(const std::string& source, const std::string& filename = "<stdin>");

    // Faylni ishga tushirish
    static int runFile(const std::string& path);
};

} // namespace velo
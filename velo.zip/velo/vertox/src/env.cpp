#include "../include/env.hpp"
#include "../include/errors.hpp"

namespace vertox {

ValuePtr Env::get(const std::string& name) {
    Env* e = this;
    while (e) {
        auto it = e->vars.find(name);
        if (it != e->vars.end()) return it->second;
        e = e->parent.get();
    }
    throw RuntimeError("Aniqlanmagan o'zgaruvchi: '" + name + "'");
}

void Env::set(const std::string& name, ValuePtr v) {
    Env* e = this;
    while (e) {
        auto it = e->vars.find(name);
        if (it != e->vars.end()) {
            it->second = std::move(v);
            return;
        }
        e = e->parent.get();
    }
    // Topilmadi - joriy scope'da yaratish
    vars[name] = std::move(v);
}

void Env::define(const std::string& name, ValuePtr v) {
    vars[name] = std::move(v);
}

bool Env::has(const std::string& name) const {
    const Env* e = this;
    while (e) {
        if (e->vars.count(name)) return true;
        e = e->parent.get();
    }
    return false;
}

std::shared_ptr<Env> Env::globalScope() {
    auto e = shared_from_this();
    while (e->parent) e = e->parent;
    return e;
}

} // namespace vertox
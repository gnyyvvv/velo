#include "../include/vm.hpp"
#include "../include/errors.hpp"
#include <iostream>
#include <cmath>
#include <chrono>
#include <cctype>
#include <algorithm>

namespace vertox {

// ============================================================
// Native builtins
// ============================================================
static ValuePtr bi_print(std::vector<ValuePtr>& args) {
    for (size_t k = 0; k < args.size(); ++k) {
        if (k) std::cout << ' ';
        std::cout << args[k]->toString();
    }
    std::cout << '\n';
    return Value::null();
}

static ValuePtr bi_input(std::vector<ValuePtr>& args) {
    if (!args.empty()) {
        std::cout << args[0]->toString();
        std::cout.flush();
    }
    std::string line;
    if (!std::getline(std::cin, line)) {
        return Value::null();
    }
    return Value::string(line);
}

static ValuePtr bi_len(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::integer(0);
    auto& v = args[0];
    switch (v->type) {
        case Value::Type::List:  return Value::integer((long long)v->list->size());
        case Value::Type::Str:   return Value::integer((long long)v->s.size());
        case Value::Type::Map:   return Value::integer((long long)v->map->size());
        case Value::Type::Tuple: return Value::integer((long long)v->tuple->size());
        default: return Value::integer(0);
    }
}

static ValuePtr bi_str(std::vector<ValuePtr>& args) {
    return Value::string(args.empty() ? "" : args[0]->toString());
}

static ValuePtr bi_int(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::integer(0);
    return Value::integer(args[0]->toInt());
}

static ValuePtr bi_float(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::floating(0.0);
    return Value::floating(args[0]->toNumber());
}

static ValuePtr bi_type(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::string("NoneType");
    switch (args[0]->type) {
        case Value::Type::Null:     return Value::string("NoneType");
        case Value::Type::Bool:     return Value::string("bool");
        case Value::Type::Int:      return Value::string("int");
        case Value::Type::Float:    return Value::string("float");
        case Value::Type::Str:      return Value::string("str");
        case Value::Type::List:     return Value::string("list");
        case Value::Type::Map:      return Value::string("dict");
        case Value::Type::Tuple:    return Value::string("tuple");
        case Value::Type::Fn:       return Value::string("function");
        case Value::Type::Native:   return Value::string("builtin_function");
        case Value::Type::Iterator: return Value::string("iterator");
        case Value::Type::Class:    return Value::string("class");
        default: return Value::string("object");
    }
}

static ValuePtr bi_range(std::vector<ValuePtr>& args) {
    long long a = 0, b = 0, step = 1;
    if (args.size() == 1) {
        b = args[0]->toInt();
    } else if (args.size() == 2) {
        a = args[0]->toInt();
        b = args[1]->toInt();
    } else if (args.size() >= 3) {
        a = args[0]->toInt();
        b = args[1]->toInt();
        step = args[2]->toInt();
        if (step == 0) throw RuntimeError("range() qadami 0 bo'lmaydi");
    }
    auto lst = std::make_shared<std::vector<ValuePtr>>();
    if (step > 0) {
        for (long long i = a; i < b; i += step)
            lst->push_back(Value::integer(i));
    } else {
        for (long long i = a; i > b; i += step)
            lst->push_back(Value::integer(i));
    }
    return Value::listOf(lst);
}

static ValuePtr bi_abs(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::integer(0);
    auto& v = args[0];
    if (v->type == Value::Type::Int) return Value::integer(std::abs(v->i));
    return Value::floating(std::fabs(v->toNumber()));
}

static ValuePtr bi_min(std::vector<ValuePtr>& args) {
    if (args.empty()) throw RuntimeError("min() kamida 1 argument oladi");
    std::vector<ValuePtr>* items = &args;
    if (args.size() == 1 && args[0]->type == Value::Type::List)
        items = args[0]->list.get();
    if (items->empty()) throw RuntimeError("min() bo'sh ro'yxat");
    auto best = (*items)[0];
    for (size_t k = 1; k < items->size(); ++k)
        if (Value::lt((*items)[k], best)) best = (*items)[k];
    return best;
}

static ValuePtr bi_max(std::vector<ValuePtr>& args) {
    if (args.empty()) throw RuntimeError("max() kamida 1 argument oladi");
    std::vector<ValuePtr>* items = &args;
    if (args.size() == 1 && args[0]->type == Value::Type::List)
        items = args[0]->list.get();
    if (items->empty()) throw RuntimeError("max() bo'sh ro'yxat");
    auto best = (*items)[0];
    for (size_t k = 1; k < items->size(); ++k)
        if (Value::gt((*items)[k], best)) best = (*items)[k];
    return best;
}

static ValuePtr bi_sum(std::vector<ValuePtr>& args) {
    if (args.empty()) return Value::integer(0);
    if (args[0]->type != Value::Type::List && args[0]->type != Value::Type::Tuple)
        throw TypeError("sum() ro'yxat yoki tuple oladi");
    ValuePtr total = Value::integer(0);
    auto& items = (args[0]->type == Value::Type::List) ? *args[0]->list : *args[0]->tuple;
    for (auto& v : items) total = Value::add(total, v);
    return total;
}

static ValuePtr bi_append(std::vector<ValuePtr>& args) {
    if (args.size() < 2) throw RuntimeError("append() 2 argument oladi");
    if (args[0]->type != Value::Type::List) throw TypeError("append() faqat list uchun");
    args[0]->list->push_back(args[1]);
    return Value::null();
}

static ValuePtr bi_pop(std::vector<ValuePtr>& args) {
    if (args.empty()) throw RuntimeError("pop() 1 argument oladi");
    auto& v = args[0];
    if (v->type == Value::Type::List) {
        if (v->list->empty()) throw IndexError("pop() bo'sh ro'yxatdan");
        long long idx = (args.size() > 1) ? args[1]->toInt() : (long long)v->list->size() - 1;
        if (idx < 0) idx += v->list->size();
        if (idx < 0 || (size_t)idx >= v->list->size())
            throw IndexError("pop() indeks chegaradan tashqari");
        auto val = (*v->list)[idx];
        v->list->erase(v->list->begin() + idx);
        return val;
    }
    if (v->type == Value::Type::Map) {
        if (args.size() < 2) throw RuntimeError("pop() map uchun kalit kerak");
        std::string key = args[1]->toString();
        auto it = v->map->find(key);
        if (it == v->map->end()) throw RuntimeError("pop() kalit topilmadi: " + key);
        auto val = it->second;
        v->map->erase(it);
        return val;
    }
    throw TypeError("pop() faqat list yoki map uchun");
}

static ValuePtr bi_push(std::vector<ValuePtr>& args) {
    if (args.size() < 2) throw RuntimeError("push() 2 argument oladi");
    if (args[0]->type != Value::Type::List) throw TypeError("push() faqat list uchun");
    args[0]->list->push_back(args[1]);
    return args[0];
}

static ValuePtr bi_keys(std::vector<ValuePtr>& args) {
    if (args.empty() || args[0]->type != Value::Type::Map)
        throw TypeError("keys() faqat dict uchun");
    auto out = std::make_shared<std::vector<ValuePtr>>();
    for (auto& kv : *args[0]->map) out->push_back(Value::string(kv.first));
    return Value::listOf(out);
}

static ValuePtr bi_values(std::vector<ValuePtr>& args) {
    if (args.empty() || args[0]->type != Value::Type::Map)
        throw TypeError("values() faqat dict uchun");
    auto out = std::make_shared<std::vector<ValuePtr>>();
    for (auto& kv : *args[0]->map) out->push_back(kv.second);
    return Value::listOf(out);
}

static ValuePtr bi_items(std::vector<ValuePtr>& args) {
    if (args.empty() || args[0]->type != Value::Type::Map)
        throw TypeError("items() faqat dict uchun");
    auto out = std::make_shared<std::vector<ValuePtr>>();
    for (auto& kv : *args[0]->map) {
        auto pair = std::make_shared<std::vector<ValuePtr>>();
        pair->push_back(Value::string(kv.first));
        pair->push_back(kv.second);
        out->push_back(Value::tupleOf(pair));
    }
    return Value::listOf(out);
}

// ============================================================
// VM
// ============================================================
VM::VM() {
    globals = std::make_shared<Env>();
    registerBuiltins();
}

VM::~VM() = default;

void VM::registerBuiltins() {
    registerNative("print",  bi_print);
    registerNative("input",  bi_input);
    registerNative("len",    bi_len);
    registerNative("str",    bi_str);
    registerNative("int",    bi_int);
    registerNative("float",  bi_float);
    registerNative("type",   bi_type);
    registerNative("range",  bi_range);
    registerNative("abs",    bi_abs);
    registerNative("min",    bi_min);
    registerNative("max",    bi_max);
    registerNative("sum",    bi_sum);
    registerNative("append", bi_append);
    registerNative("pop",    bi_pop);
    registerNative("push",   bi_push);
    registerNative("keys",   bi_keys);
    registerNative("values", bi_values);
    registerNative("items",  bi_items);
}

void VM::registerNative(const std::string& name, NativeFn fn) {
    globals->vars[name] = Value::nativeFunc(fn);
}

// ============================================================
// Asosiy run loop
// ============================================================
ValuePtr VM::run(const std::vector<Instr>& code,
                 const std::vector<ValuePtr>& consts,
                 std::shared_ptr<Env> env)
{
    if (!env) env = globals;

    auto t_start = std::chrono::high_resolution_clock::now();

    std::vector<ValuePtr> stack;
    stack.reserve(256);

    size_t ip = 0;
    const size_t n = code.size();
    const Instr* pc = code.data();

    auto pop = [&]() -> ValuePtr {
        auto v = std::move(stack.back());
        stack.pop_back();
        return v;
    };
    auto push = [&](ValuePtr v) { stack.push_back(std::move(v)); };

    try {
        while (ip < n) {
            const Instr ins = pc[ip++];
            stats_.instructions++;

            if (trace_) {
                std::cout << "[VM] ip=" << (ip-1) << " " << opName(ins.op)
                          << " arg=" << ins.arg
                          << " stack=" << stack.size() << "\n";
            }

            switch (ins.op) {

            case Op::PUSH:  push(consts[ins.arg]); break;
            case Op::POP:   if (!stack.empty()) stack.pop_back(); break;
            case Op::DUP:   push(stack.back()); break;
            case Op::SWAP: {
                if (stack.size() < 2) throw RuntimeError("SWAP: stack juda kichik");
                std::swap(stack[stack.size()-1], stack[stack.size()-2]);
                break;
            }

            case Op::PUSH_TRUE:  push(Value::boolean(true)); break;
            case Op::PUSH_FALSE: push(Value::boolean(false)); break;
            case Op::PUSH_NULL:  push(Value::null()); break;
            case Op::PUSH_INT:   push(Value::integer(ins.arg)); break;

            case Op::LOAD: {
                const std::string& name = consts[ins.arg]->s;
                push(env->get(name));
                break;
            }
            case Op::STORE: {
                const std::string& name = consts[ins.arg]->s;
                env->set(name, pop());
                break;
            }
            case Op::DEFINE: {
                const std::string& name = consts[ins.arg]->s;
                env->define(name, pop());
                break;
            }

            case Op::BUILD_LIST: {
                auto lst = std::make_shared<std::vector<ValuePtr>>();
                lst->reserve(ins.arg);
                size_t start = stack.size() - ins.arg;
                for (size_t k = start; k < stack.size(); ++k)
                    lst->push_back(stack[k]);
                stack.resize(start);
                push(Value::listOf(lst));
                break;
            }
            case Op::BUILD_TUPLE: {
                auto tup = std::make_shared<std::vector<ValuePtr>>();
                tup->reserve(ins.arg);
                size_t start = stack.size() - ins.arg;
                for (size_t k = start; k < stack.size(); ++k)
                    tup->push_back(stack[k]);
                stack.resize(start);
                push(Value::tupleOf(tup));
                break;
            }
            case Op::BUILD_MAP: {
                auto mp = std::make_shared<std::unordered_map<std::string, ValuePtr>>();
                size_t start = stack.size() - ins.arg * 2;
                for (size_t k = 0; k < (size_t)ins.arg; ++k) {
                    auto key = stack[start + k*2]->toString();
                    (*mp)[key] = stack[start + k*2 + 1];
                }
                stack.resize(start);
                push(Value::mapOf(mp));
                break;
            }
            case Op::INDEX: {
                auto idx = pop();
                auto obj = pop();

                if (obj->type == Value::Type::List) {
                    long long i = idx->toInt();
                    auto& L = *obj->list;
                    if (i < 0) i += L.size();
                    if (i < 0 || (size_t)i >= L.size())
                        throw IndexError("Indeks chegaradan tashqari: " + std::to_string(i));
                    push(L[i]);
                }
                else if (obj->type == Value::Type::Tuple) {
                    long long i = idx->toInt();
                    auto& T = *obj->tuple;
                    if (i < 0) i += T.size();
                    if (i < 0 || (size_t)i >= T.size())
                        throw IndexError("Indeks chegaradan tashqari");
                    push(T[i]);
                }
                else if (obj->type == Value::Type::Str) {
                    long long i = idx->toInt();
                    auto& S = obj->s;
                    if (i < 0) i += S.size();
                    if (i < 0 || (size_t)i >= S.size())
                        throw IndexError("String indeks chegaradan tashqari");
                    push(Value::string(std::string(1, S[i])));
                }
                else if (obj->type == Value::Type::Map) {
                    std::string key = idx->toString();
                    auto it = obj->map->find(key);
                    push(it != obj->map->end() ? it->second : Value::null());
                }
                else {
                    throw TypeError("Indekslab bo'lmaydi: " + obj->toString());
                }
                break;
            }
            case Op::SET_INDEX: {
                auto idx = pop();
                auto obj = pop();
                auto val = pop();

                if (obj->type == Value::Type::List) {
                    long long i = idx->toInt();
                    auto& L = *obj->list;
                    if (i < 0) i += L.size();
                    if (i < 0 || (size_t)i >= L.size())
                        throw IndexError("Indeks chegaradan tashqari");
                    L[i] = val;
                }
                else if (obj->type == Value::Type::Map) {
                    (*obj->map)[idx->toString()] = val;
                }
                else {
                    throw TypeError("SET_INDEX faqat list yoki map uchun");
                }
                break;
            }

            case Op::ADD: { auto b = pop(); auto a = pop(); push(Value::add(a, b)); break; }
            case Op::SUB: { auto b = pop(); auto a = pop(); push(Value::sub(a, b)); break; }
            case Op::MUL: { auto b = pop(); auto a = pop(); push(Value::mul(a, b)); break; }
            case Op::DIV: { auto b = pop(); auto a = pop(); push(Value::div(a, b)); break; }
            case Op::IDIV:{ auto b = pop(); auto a = pop(); push(Value::idiv(a, b)); break; }
            case Op::MOD: { auto b = pop(); auto a = pop(); push(Value::mod(a, b)); break; }
            case Op::POW: { auto b = pop(); auto a = pop(); push(Value::pow(a, b)); break; }
            case Op::NEG: {
                auto a = pop();
                if (a->type == Value::Type::Int) push(Value::integer(-a->i));
                else push(Value::floating(-a->toNumber()));
                break;
            }

            case Op::EQ:  { auto b = pop(); auto a = pop(); push(Value::boolean(Value::eq(a, b))); break; }
            case Op::NEQ: { auto b = pop(); auto a = pop(); push(Value::boolean(!Value::eq(a, b))); break; }
            case Op::LT:  { auto b = pop(); auto a = pop(); push(Value::boolean(Value::lt(a, b))); break; }
            case Op::GT:  { auto b = pop(); auto a = pop(); push(Value::boolean(Value::gt(a, b))); break; }
            case Op::LE:  { auto b = pop(); auto a = pop(); push(Value::boolean(!Value::gt(a, b))); break; }
            case Op::GE:  { auto b = pop(); auto a = pop(); push(Value::boolean(!Value::lt(a, b))); break; }
            case Op::IN: {
                auto container = pop();
                auto item = pop();
                bool found = false;
                if (container->type == Value::Type::List) {
                    for (auto& v : *container->list) if (Value::eq(item, v)) { found = true; break; }
                } else if (container->type == Value::Type::Str) {
                    found = container->s.find(item->toString()) != std::string::npos;
                } else if (container->type == Value::Type::Map) {
                    found = container->map->count(item->toString()) > 0;
                }
                push(Value::boolean(found));
                break;
            }

            case Op::NOT: { auto a = pop(); push(Value::boolean(!a->truthy())); break; }

            case Op::JUMP: ip = (size_t)ins.arg; break;
            case Op::JUMP_IF_FALSE: {
                auto a = pop();
                if (!a->truthy()) ip = (size_t)ins.arg;
                break;
            }
            case Op::JUMP_IF_TRUE: {
                auto a = pop();
                if (a->truthy()) ip = (size_t)ins.arg;
                break;
            }
            case Op::JUMP_IF_FALSE_KEEP: {
                if (!stack.back()->truthy()) ip = (size_t)ins.arg;
                else stack.pop_back();
                break;
            }
            case Op::JUMP_IF_TRUE_KEEP: {
                if (stack.back()->truthy()) ip = (size_t)ins.arg;
                else stack.pop_back();
                break;
            }

            case Op::MAKE_FN: {
                auto fnVal = consts[ins.arg];
                if (fnVal->type == Value::Type::Fn && fnVal->fn) {
                    fnVal->fn->closure = env;
                }
                push(fnVal);
                break;
            }

            case Op::CALL: {
                int argc = (int)ins.arg;
                if (stack.size() < (size_t)(argc + 1))
                    throw RuntimeError("CALL: stack juda kichik");

                auto callee = stack.back();
                stack.pop_back();

                size_t start = stack.size() - argc;
                std::vector<ValuePtr> args(stack.begin() + start, stack.end());
                stack.resize(start);

                stats_.calls++;

                if (callee->type == Value::Type::Native) {
                    push(callee->native(args));
                }
                else if (callee->type == Value::Type::Fn) {
                    auto fn = callee->fn;
                    auto callEnv = std::make_shared<Env>(fn->closure, fn->name);

                    for (size_t k = 0; k < fn->params.size() && k < args.size(); ++k) {
                        callEnv->vars[fn->params[k]] = args[k];
                    }

                    ValuePtr retVal = run(fn->code, fn->consts, callEnv);
                    push(retVal);
                }
                else {
                    throw TypeError("Chaqirib bo'lmaydi: " + callee->toString());
                }
                break;
            }

            case Op::RETURN:
                throw ReturnSignal{pop()};
            case Op::RETURN_NULL:
                throw ReturnSignal{Value::null()};

            case Op::GET_ITER: {
                auto src = pop();
                auto it = std::make_shared<Iterator>();
                it->source = src;
                if (src->type == Value::Type::List)       it->kind = Iterator::Kind::List;
                else if (src->type == Value::Type::Str)   it->kind = Iterator::Kind::Str;
                else if (src->type == Value::Type::Tuple) it->kind = Iterator::Kind::Tuple;
                else throw TypeError("Iteratsiya qilib bo'lmaydi: " + src->toString());
                push(Value::iterator(it));
                break;
            }
            case Op::ITER_NEXT: {
                auto it = stack.back()->iter;
                if (!it->hasNext()) ip = (size_t)ins.arg;
                break;
            }
            case Op::ITER_VALUE: {
                auto it = stack.back()->iter;
                if (!it->hasNext()) throw RuntimeError("ITER_VALUE: iterator tugadi");
                push(it->next());
                break;
            }

            // ============================================================
            // GET_ATTR - xossa olish (obj.attr)
            // ============================================================
            case Op::GET_ATTR: {
                std::string attrName = consts[ins.arg]->s;
                auto obj = stack.back();
                stack.pop_back();

                if (obj->type == Value::Type::Str ||
                    obj->type == Value::Type::List ||
                    obj->type == Value::Type::Map) {
                    auto methodVal = std::make_shared<Value>();
                    methodVal->type = Value::Type::Native;
                    methodVal->s = attrName;
                    methodVal->instance_of = obj;
                    push(methodVal);
                    break;
                }

                push(Value::null());
                break;
            }

            // ============================================================
            // CALL_METHOD - metod chaqirish
            // ============================================================
            case Op::CALL_METHOD: {
                int argc = (int)ins.arg;
                if (stack.size() < (size_t)(argc + 1))
                    throw RuntimeError("CALL_METHOD: stack juda kichik");

                auto method = stack.back();
                stack.pop_back();

                size_t start = stack.size() - argc;
                std::vector<ValuePtr> args(stack.begin() + start, stack.end());
                stack.resize(start);

                auto obj = method->instance_of;
                const std::string& name = method->s;
                ValuePtr result = Value::null();

                // === STRING METODLARI ===
                if (obj->type == Value::Type::Str) {
                    const std::string& s = obj->s;

                    if (name == "upper") {
                        std::string r = s;
                        for (auto& c : r) c = std::toupper((unsigned char)c);
                        result = Value::string(r);
                    }
                    else if (name == "lower") {
                        std::string r = s;
                        for (auto& c : r) c = std::tolower((unsigned char)c);
                        result = Value::string(r);
                    }
                    else if (name == "strip") {
                        size_t b = s.find_first_not_of(" \t\n\r");
                        size_t e = s.find_last_not_of(" \t\n\r");
                        if (b == std::string::npos) result = Value::string("");
                        else result = Value::string(s.substr(b, e - b + 1));
                    }
                    else if (name == "split") {
                        std::string sep = args.empty() ? " " : args[0]->toString();
                        auto out = std::make_shared<std::vector<ValuePtr>>();
                        if (sep.empty()) {
                            for (char c : s) out->push_back(Value::string(std::string(1, c)));
                        } else {
                            size_t startPos = 0, pos;
                            while ((pos = s.find(sep, startPos)) != std::string::npos) {
                                out->push_back(Value::string(s.substr(startPos, pos - startPos)));
                                startPos = pos + sep.length();
                            }
                            out->push_back(Value::string(s.substr(startPos)));
                        }
                        result = Value::listOf(out);
                    }
                    else if (name == "replace") {
                        if (args.size() < 2) throw RuntimeError("replace 2 argument oladi");
                        std::string from = args[0]->toString();
                        std::string to = args[1]->toString();
                        std::string r = s;
                        size_t pos = 0;
                        while ((pos = r.find(from, pos)) != std::string::npos) {
                            r.replace(pos, from.length(), to);
                            pos += to.length();
                        }
                        result = Value::string(r);
                    }
                    else if (name == "startswith") {
                        if (args.empty()) throw RuntimeError("startswith 1 argument oladi");
                        std::string prefix = args[0]->toString();
                        bool b = s.size() >= prefix.size() &&
                                 s.compare(0, prefix.size(), prefix) == 0;
                        result = Value::boolean(b);
                    }
                    else if (name == "endswith") {
                        if (args.empty()) throw RuntimeError("endswith 1 argument oladi");
                        std::string suffix = args[0]->toString();
                        bool b = s.size() >= suffix.size() &&
                                 s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
                        result = Value::boolean(b);
                    }
                    else if (name == "find") {
                        if (args.empty()) throw RuntimeError("find 1 argument oladi");
                        std::string sub = args[0]->toString();
                        size_t pos = s.find(sub);
                        result = Value::integer(pos == std::string::npos ? -1 : (long long)pos);
                    }
                    else if (name == "count") {
                        if (args.empty()) throw RuntimeError("count 1 argument oladi");
                        std::string sub = args[0]->toString();
                        long long cnt = 0;
                        size_t pos = 0;
                        while ((pos = s.find(sub, pos)) != std::string::npos) {
                            cnt++;
                            pos += sub.length();
                        }
                        result = Value::integer(cnt);
                    }
                    else if (name == "capitalize") {
                        std::string r = s;
                        if (!r.empty()) {
                            r[0] = std::toupper((unsigned char)r[0]);
                            for (size_t i = 1; i < r.size(); ++i)
                                r[i] = std::tolower((unsigned char)r[i]);
                        }
                        result = Value::string(r);
                    }
                    else if (name == "title") {
                        std::string r = s;
                        bool newWord = true;
                        for (auto& c : r) {
                            if (std::isspace((unsigned char)c)) newWord = true;
                            else {
                                if (newWord) c = std::toupper((unsigned char)c);
                                else c = std::tolower((unsigned char)c);
                                newWord = false;
                            }
                        }
                        result = Value::string(r);
                    }
                    else if (name == "join") {
                        if (args.empty()) throw RuntimeError("join 1 argument oladi");
                        if (args[0]->type != Value::Type::List)
                            throw TypeError("join list oladi");
                        std::string r;
                        auto& items = *args[0]->list;
                        for (size_t i = 0; i < items.size(); ++i) {
                            if (i) r += s;
                            r += items[i]->toString();
                        }
                        result = Value::string(r);
                    }
                    else if (name == "isdigit") {
                        bool b = !s.empty();
                        for (auto c : s) if (!std::isdigit((unsigned char)c)) { b = false; break; }
                        result = Value::boolean(b);
                    }
                    else if (name == "isalpha") {
                        bool b = !s.empty();
                        for (auto c : s) if (!std::isalpha((unsigned char)c)) { b = false; break; }
                        result = Value::boolean(b);
                    }
                    else if (name == "isspace") {
                        bool b = !s.empty();
                        for (auto c : s) if (!std::isspace((unsigned char)c)) { b = false; break; }
                        result = Value::boolean(b);
                    }
                    else {
                        throw RuntimeError("Noma'lum string metodi: " + name);
                    }
                }

                // === LIST METODLARI ===
                else if (obj->type == Value::Type::List) {
                    auto& L = *obj->list;

                    if (name == "append") {
                        if (args.empty()) throw RuntimeError("append 1 argument oladi");
                        L.push_back(args[0]);
                        result = Value::null();
                    }
                    else if (name == "pop") {
                        if (L.empty()) throw IndexError("pop bo'sh ro'yxatdan");
                        long long idx = args.empty() ? (long long)L.size() - 1 : args[0]->toInt();
                        if (idx < 0) idx += L.size();
                        if (idx < 0 || (size_t)idx >= L.size())
                            throw IndexError("pop indeks xatosi");
                        result = L[idx];
                        L.erase(L.begin() + idx);
                    }
                    else if (name == "insert") {
                        if (args.size() < 2) throw RuntimeError("insert 2 argument oladi");
                        long long idx = args[0]->toInt();
                        if (idx < 0) idx += L.size();
                        if (idx < 0) idx = 0;
                        if ((size_t)idx > L.size()) idx = L.size();
                        L.insert(L.begin() + idx, args[1]);
                        result = Value::null();
                    }
                    else if (name == "remove") {
                        if (args.empty()) throw RuntimeError("remove 1 argument oladi");
                        for (size_t i = 0; i < L.size(); ++i) {
                            if (Value::eq(L[i], args[0])) {
                                L.erase(L.begin() + i);
                                result = Value::null();
                                break;
                            }
                        }
                    }
                    else if (name == "index") {
                        if (args.empty()) throw RuntimeError("index 1 argument oladi");
                        long long found = -1;
                        for (size_t i = 0; i < L.size(); ++i) {
                            if (Value::eq(L[i], args[0])) { found = (long long)i; break; }
                        }
                        if (found < 0) throw RuntimeError("index topilmadi");
                        result = Value::integer(found);
                    }
                    else if (name == "count") {
                        if (args.empty()) throw RuntimeError("count 1 argument oladi");
                        long long cnt = 0;
                        for (auto& v : L) if (Value::eq(v, args[0])) cnt++;
                        result = Value::integer(cnt);
                    }
                    else if (name == "reverse") {
                        std::reverse(L.begin(), L.end());
                        result = Value::null();
                    }
                    else if (name == "sort") {
                        std::sort(L.begin(), L.end(), [](const ValuePtr& a, const ValuePtr& b) {
                            return Value::lt(a, b);
                        });
                        result = Value::null();
                    }
                    else if (name == "clear") {
                        L.clear();
                        result = Value::null();
                    }
                    else if (name == "copy") {
                        auto newList = std::make_shared<std::vector<ValuePtr>>(L);
                        result = Value::listOf(newList);
                    }
                    else if (name == "extend") {
                        if (args.empty()) throw RuntimeError("extend 1 argument oladi");
                        if (args[0]->type != Value::Type::List)
                            throw TypeError("extend list oladi");
                        L.insert(L.end(), args[0]->list->begin(), args[0]->list->end());
                        result = Value::null();
                    }
                    else {
                        throw RuntimeError("Noma'lum list metodi: " + name);
                    }
                }

                // === DICT METODLARI ===
                else if (obj->type == Value::Type::Map) {
                    auto& M = *obj->map;

                    if (name == "keys") {
                        auto out = std::make_shared<std::vector<ValuePtr>>();
                        for (auto& kv : M) out->push_back(Value::string(kv.first));
                        result = Value::listOf(out);
                    }
                    else if (name == "values") {
                        auto out = std::make_shared<std::vector<ValuePtr>>();
                        for (auto& kv : M) out->push_back(kv.second);
                        result = Value::listOf(out);
                    }
                    else if (name == "items") {
                        auto out = std::make_shared<std::vector<ValuePtr>>();
                        for (auto& kv : M) {
                            auto pair = std::make_shared<std::vector<ValuePtr>>();
                            pair->push_back(Value::string(kv.first));
                            pair->push_back(kv.second);
                            out->push_back(Value::tupleOf(pair));
                        }
                        result = Value::listOf(out);
                    }
                    else if (name == "get") {
                        if (args.empty()) throw RuntimeError("get 1 argument oladi");
                        std::string key = args[0]->toString();
                        auto it = M.find(key);
                        if (it != M.end()) result = it->second;
                        else if (args.size() > 1) result = args[1];
                        else result = Value::null();
                    }
                    else if (name == "pop") {
                        if (args.empty()) throw RuntimeError("pop 1 argument oladi");
                        std::string key = args[0]->toString();
                        auto it = M.find(key);
                        if (it == M.end()) {
                            if (args.size() > 1) result = args[1];
                            else throw RuntimeError("pop kalit topilmadi");
                        } else {
                            result = it->second;
                            M.erase(it);
                        }
                    }
                    else if (name == "clear") {
                        M.clear();
                        result = Value::null();
                    }
                    else if (name == "copy") {
                        auto newMap = std::make_shared<std::unordered_map<std::string, ValuePtr>>(M);
                        result = Value::mapOf(newMap);
                    }
                    else {
                        throw RuntimeError("Noma'lum dict metodi: " + name);
                    }
                }

                push(result);
                break;
            }

            case Op::NOP: break;
            case Op::HALT: {
                return stack.empty() ? Value::null() : stack.back();
            }
            case Op::PRINT: {
                auto v = pop();
                std::cout << v->toString() << '\n';
                break;
            }
            case Op::DEBUG: {
                std::cout << "[DEBUG] stack size=" << stack.size();
                if (!stack.empty()) std::cout << " top=" << stack.back()->toString();
                std::cout << '\n';
                break;
            }

            default:
                throw RuntimeError("Noma'lum opcode: " + std::string(opName(ins.op)));
            }
        }
    }
    catch (ReturnSignal& r) {
        return r.value;
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    stats_.time_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    return stack.empty() ? Value::null() : stack.back();
}

} // namespace vertox
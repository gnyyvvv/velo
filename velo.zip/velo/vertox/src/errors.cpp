#include "../include/errors.hpp"
#include <iostream>

namespace vertox {

// Hozircha bo'sh - hamma narsa header'da inline
// Kelajakda stack trace qo'shiladi

} // namespace vertox
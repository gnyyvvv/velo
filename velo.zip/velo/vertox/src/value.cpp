#include "../include/value.hpp"
#include "../include/errors.hpp"
#include <cmath>
#include <sstream>
#include <iomanip>

namespace vertox {

// ============================================================
// Konstruktorlar
// ============================================================
ValuePtr Value::null() {
    auto v = std::make_shared<Value>();
    v->type = Type::Null;
    return v;
}

ValuePtr Value::boolean(bool x) {
    auto v = std::make_shared<Value>();
    v->type = Type::Bool;
    v->b = x;
    return v;
}

ValuePtr Value::integer(long long x) {
    auto v = std::make_shared<Value>();
    v->type = Type::Int;
    v->i = x;
    return v;
}

ValuePtr Value::floating(double x) {
    auto v = std::make_shared<Value>();
    v->type = Type::Float;
    v->f = x;
    return v;
}

ValuePtr Value::string(std::string x) {
    auto v = std::make_shared<Value>();
    v->type = Type::Str;
    v->s = std::move(x);
    return v;
}

ValuePtr Value::listOf(ListPtr l) {
    auto v = std::make_shared<Value>();
    v->type = Type::List;
    v->list = std::move(l);
    return v;
}

ValuePtr Value::listOf(std::vector<ValuePtr> items) {
    auto lst = std::make_shared<std::vector<ValuePtr>>(std::move(items));
    return listOf(lst);
}

ValuePtr Value::mapOf(MapPtr m) {
    auto v = std::make_shared<Value>();
    v->type = Type::Map;
    v->map = std::move(m);
    return v;
}

ValuePtr Value::tupleOf(TuplePtr t) {
    auto v = std::make_shared<Value>();
    v->type = Type::Tuple;
    v->tuple = std::move(t);
    return v;
}

ValuePtr Value::func(FnPtr f) {
    auto v = std::make_shared<Value>();
    v->type = Type::Fn;
    v->fn = std::move(f);
    return v;
}

ValuePtr Value::nativeFunc(NativeFn f) {
    auto v = std::make_shared<Value>();
    v->type = Type::Native;
    v->native = f;
    return v;
}

ValuePtr Value::iterator(IterPtr it) {
    auto v = std::make_shared<Value>();
    v->type = Type::Iterator;
    v->iter = std::move(it);
    return v;
}

ValuePtr Value::classObj(ClassPtr c) {
    auto v = std::make_shared<Value>();
    v->type = Type::Class;
    v->cls = std::move(c);
    return v;
}

// ============================================================
// Forward declaration (repr uchun kerak)
// ============================================================
static std::string valueRepr(const ValuePtr& v);

// ============================================================
// toString
// ============================================================
std::string Value::toString() const {
    switch (type) {
        case Type::Null:   return "None";
        case Type::Bool:   return b ? "True" : "False";
        case Type::Int:    return std::to_string(i);
        case Type::Float: {
            std::ostringstream oss;
            if (f == (long long)f && std::fabs(f) < 1e15) {
                oss << f << ".0";
            } else {
                oss << std::setprecision(15) << f;
            }
            return oss.str();
        }
        case Type::Str:    return s;

        case Type::List: {
            std::string out = "[";
            for (size_t k = 0; k < list->size(); ++k) {
                if (k) out += ", ";
                out += valueRepr((*list)[k]);
            }
            return out + "]";
        }
        case Type::Tuple: {
            std::string out = "(";
            for (size_t k = 0; k < tuple->size(); ++k) {
                if (k) out += ", ";
                out += valueRepr((*tuple)[k]);
            }
            if (tuple->size() == 1) out += ",";
            return out + ")";
        }
        case Type::Map: {
            std::string out = "{";
            bool first = true;
            for (auto& kv : *map) {
                if (!first) out += ", ";
                first = false;
                out += "\"" + kv.first + "\": " + valueRepr(kv.second);
            }
            return out + "}";
        }
        case Type::Fn:     return "<function " + fn->name + ">";
        case Type::Native: return "<built-in function>";
        case Type::Iterator: return "<iterator>";
        case Type::Class:  return "<class '" + cls->name + "'>";
        case Type::Instance: return "<object>";
    }
    return "?";
}

std::string Value::repr() const {
    if (type == Type::Str) return "'" + s + "'";
    return toString();
}

// Helper
static std::string valueRepr(const ValuePtr& v) {
    if (!v) return "None";
    return v->repr();
}

// ============================================================
// truthy
// ============================================================
bool Value::truthy() const {
    switch (type) {
        case Type::Null:   return false;
        case Type::Bool:   return b;
        case Type::Int:    return i != 0;
        case Type::Float:  return f != 0.0;
        case Type::Str:    return !s.empty();
        case Type::List:   return !list->empty();
        case Type::Map:    return !map->empty();
        case Type::Tuple:  return !tuple->empty();
        default:           return true;
    }
}

// ============================================================
// toNumber
// ============================================================
double Value::toNumber() const {
    switch (type) {
        case Type::Int:    return (double)i;
        case Type::Float:  return f;
        case Type::Bool:   return b ? 1.0 : 0.0;
        case Type::Str: {
            try { return std::stod(s); }
            catch (...) { throw TypeError("'" + s + "' ni songa aylantirib bo'lmaydi"); }
        }
        default:
            throw TypeError("'" + toString() + "' ni songa aylantirib bo'lmaydi");
    }
}

long long Value::toInt() const {
    return (long long)toNumber();
}

// ============================================================
// Operatorlar
// ============================================================
ValuePtr Value::add(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Str || b->type == Type::Str) {
        return Value::string(a->toString() + b->toString());
    }
    if (a->type == Type::List && b->type == Type::List) {
        auto out = std::make_shared<std::vector<ValuePtr>>(*a->list);
        out->insert(out->end(), b->list->begin(), b->list->end());
        return Value::listOf(out);
    }
    if (a->type == Type::Tuple && b->type == Type::Tuple) {
        auto out = std::make_shared<std::vector<ValuePtr>>(*a->tuple);
        out->insert(out->end(), b->tuple->begin(), b->tuple->end());
        return Value::tupleOf(out);
    }
    if (a->type == Type::Int && b->type == Type::Int) {
        return Value::integer(a->i + b->i);
    }
    return Value::floating(a->toNumber() + b->toNumber());
}

ValuePtr Value::sub(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Int && b->type == Type::Int)
        return Value::integer(a->i - b->i);
    return Value::floating(a->toNumber() - b->toNumber());
}

ValuePtr Value::mul(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Str && b->type == Type::Int) {
        std::string out;
        for (long long k = 0; k < b->i; ++k) out += a->s;
        return Value::string(out);
    }
    if (a->type == Type::Int && b->type == Type::Str) {
        std::string out;
        for (long long k = 0; k < a->i; ++k) out += b->s;
        return Value::string(out);
    }
    if (a->type == Type::List && b->type == Type::Int) {
        auto out = std::make_shared<std::vector<ValuePtr>>();
        for (long long k = 0; k < b->i; ++k)
            out->insert(out->end(), a->list->begin(), a->list->end());
        return Value::listOf(out);
    }
    if (a->type == Type::Int && b->type == Type::Int)
        return Value::integer(a->i * b->i);
    return Value::floating(a->toNumber() * b->toNumber());
}

ValuePtr Value::div(const ValuePtr& a, const ValuePtr& b) {
    double d = b->toNumber();
    if (d == 0.0) throw RuntimeError("Nolga bo'lish");
    return Value::floating(a->toNumber() / d);
}

ValuePtr Value::idiv(const ValuePtr& a, const ValuePtr& b) {
    double d = b->toNumber();
    if (d == 0.0) throw RuntimeError("Nolga bo'lish");
    return Value::integer((long long)std::floor(a->toNumber() / d));
}

ValuePtr Value::mod(const ValuePtr& a, const ValuePtr& b) {
    double d = b->toNumber();
    if (d == 0.0) throw RuntimeError("Nolga bo'lish");
    double r = std::fmod(a->toNumber(), d);
    if ((r < 0 && d > 0) || (r > 0 && d < 0)) r += d;
    return Value::floating(r);
}

ValuePtr Value::pow(const ValuePtr& a, const ValuePtr& b) {
    double result = std::pow(a->toNumber(), b->toNumber());
    if (a->type == Type::Int && b->type == Type::Int && b->i >= 0) {
        return Value::integer((long long)result);
    }
    return Value::floating(result);
}

// ============================================================
// Taqqoslash
// ============================================================
bool Value::eq(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Null && b->type == Type::Null) return true;
    if (a->type == Type::Null || b->type == Type::Null) return false;
    if (a->type == Type::Bool && b->type == Type::Bool) return a->b == b->b;
    if (a->isNumber() && b->isNumber()) return a->toNumber() == b->toNumber();
    if (a->type == Type::Str && b->type == Type::Str) return a->s == b->s;
    if (a->type == Type::List && b->type == Type::List) {
        if (a->list->size() != b->list->size()) return false;
        for (size_t k = 0; k < a->list->size(); ++k)
            if (!eq((*a->list)[k], (*b->list)[k])) return false;
        return true;
    }
    return false;
}

bool Value::lt(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Str && b->type == Type::Str) return a->s < b->s;
    return a->toNumber() < b->toNumber();
}

bool Value::gt(const ValuePtr& a, const ValuePtr& b) {
    if (a->type == Type::Str && b->type == Type::Str) return a->s > b->s;
    return a->toNumber() > b->toNumber();
}

// ============================================================
// Iterator
// ============================================================
bool Iterator::hasNext() const {
    switch (kind) {
        case Kind::List:    return index < source->list->size();
        case Kind::Str:     return index < source->s.size();
        case Kind::Tuple:   return index < source->tuple->size();
        case Kind::Range:   return index < (size_t)source->i;
        default:            return false;
    }
}

ValuePtr Iterator::next() {
    if (!hasNext()) throw RuntimeError("Iterator tugadi");
    switch (kind) {
        case Kind::List:    return (*source->list)[index++];
        case Kind::Str:     return Value::string(std::string(1, source->s[index++]));
        case Kind::Tuple:   return (*source->tuple)[index++];
        case Kind::Range:   return Value::integer(index++);
        default:            return Value::null();
    }
}

} // namespace vertox
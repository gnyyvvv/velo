#include "../include/vm.hpp"
#include "../include/opcode.hpp"
#include "../include/value.hpp"
#include "../include/errors.hpp"
#include <iostream>

using namespace vertox;

static int passed = 0;
static int failed = 0;

#define TEST(name, expr) do { \
    std::cout << "  " << name << "... "; \
    try { \
        if (expr) { std::cout << "OK\n"; passed++; } \
        else { std::cout << "FAIL\n"; failed++; } \
    } catch (std::exception& e) { \
        std::cout << "XATO: " << e.what() << "\n"; failed++; \
    } \
} while(0)

static ValuePtr safeRun(VM& vm, const std::vector<Instr>& code, const std::vector<ValuePtr>& consts) {
    try {
        return vm.run(code, consts);
    } catch (std::exception& e) {
        std::cout << "    [XATO] " << e.what() << "\n";
        return Value::null();
    }
}

void test_add() {
    std::cout << "\n[TEST 1] 2 + 3 = 5\n";
    std::vector<Instr> code = {
        {Op::PUSH_INT, 2},
        {Op::PUSH_INT, 3},
        {Op::ADD},
        {Op::HALT}
    };
    std::vector<ValuePtr> consts;
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("natija 5 ga teng", result->type == Value::Type::Int && result->i == 5);
}

void test_str_concat() {
    std::cout << "\n[TEST 2] \"Salom\" + \" Dunyo\"\n";
    std::vector<ValuePtr> consts = {
        Value::string("Salom"),
        Value::string(" Dunyo")
    };
    std::vector<Instr> code = {
        {Op::PUSH, 0},
        {Op::PUSH, 1},
        {Op::ADD},
        {Op::HALT}
    };
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("natija \"Salom Dunyo\"", result->type == Value::Type::Str && result->s == "Salom Dunyo");
}

void test_list() {
    std::cout << "\n[TEST 3] [1, 2, 3]\n";
    std::vector<Instr> code = {
        {Op::PUSH_INT, 1},
        {Op::PUSH_INT, 2},
        {Op::PUSH_INT, 3},
        {Op::BUILD_LIST, 3},
        {Op::HALT}
    };
    std::vector<ValuePtr> consts;
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("list, 3 element", result->type == Value::Type::List && result->list->size() == 3);
    TEST("birinchi element 1",
         result->list->size() > 0 && (*result->list)[0]->i == 1);
}

void test_variables() {
    std::cout << "\n[TEST 4] x = 10; y = x + 5\n";
    std::vector<ValuePtr> consts = {
        Value::string("x"),
        Value::string("y")
    };
    std::vector<Instr> code = {
        {Op::PUSH_INT, 10},
        {Op::DEFINE, 0},
        {Op::LOAD, 0},
        {Op::PUSH_INT, 5},
        {Op::ADD},
        {Op::DEFINE, 1},
        {Op::LOAD, 1},
        {Op::HALT}
    };
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("y == 15", result->type == Value::Type::Int && result->i == 15);
}

void test_if() {
    std::cout << "\n[TEST 5] if (10 > 5) -> 100 else 200\n";
    std::vector<Instr> code = {
        {Op::PUSH_INT, 10},
        {Op::PUSH_INT, 5},
        {Op::GT},
        {Op::JUMP_IF_FALSE, 6},
        {Op::PUSH_INT, 100},
        {Op::JUMP, 7},
        {Op::PUSH_INT, 200},
        {Op::HALT}
    };
    std::vector<ValuePtr> consts;
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("natija 100", result->type == Value::Type::Int && result->i == 100);
}

void test_loop_sum() {
    std::cout << "\n[TEST 6] 1+2+...+10 = 55\n";
    std::vector<ValuePtr> consts = {
        Value::string("total"),
        Value::string("i")
    };
    std::vector<Instr> code = {
        {Op::PUSH_INT, 0},        // 0
        {Op::DEFINE, 0},          // 1: total = 0
        {Op::PUSH_INT, 1},        // 2
        {Op::DEFINE, 1},          // 3: i = 1
        {Op::LOAD, 1},            // 4: loop
        {Op::PUSH_INT, 10},       // 5
        {Op::GT},                 // 6
        {Op::JUMP_IF_FALSE, 17},  // 7: -> end
        {Op::LOAD, 0},            // 8
        {Op::LOAD, 1},            // 9
        {Op::ADD},                // 10
        {Op::STORE, 0},           // 11
        {Op::LOAD, 1},            // 12
        {Op::PUSH_INT, 1},        // 13
        {Op::ADD},                // 14
        {Op::STORE, 1},           // 15
        {Op::JUMP, 4},            // 16
        {Op::LOAD, 0},            // 17: end
        {Op::HALT}                // 18
    };
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("yig'indi 55", result->type == Value::Type::Int && result->i == 55);
}

void test_native() {
    std::cout << "\n[TEST 7] len([1, 2, 3]) = 3\n";
    std::vector<Instr> code = {
        {Op::PUSH_INT, 1},
        {Op::PUSH_INT, 2},
        {Op::PUSH_INT, 3},
        {Op::BUILD_LIST, 3},
        {Op::LOAD, 0},
        {Op::CALL, 1},
        {Op::HALT}
    };
    std::vector<ValuePtr> consts = { Value::string("len") };
    VM vm;
    auto result = safeRun(vm, code, consts);
    TEST("len == 3", result->type == Value::Type::Int && result->i == 3);
}

int main() {
    std::cout << "========================================\n";
    std::cout << "  Vertox Engine v0.1 - Test Suite\n";
    std::cout << "========================================\n";

    test_add();
    test_str_concat();
    test_list();
    test_variables();
    test_if();
    test_loop_sum();
    test_native();

    std::cout << "\n========================================\n";
    std::cout << "  Natija: " << passed << " o'tdi, " << failed << " muvaffaqiyatsiz\n";
    std::cout << "========================================\n";

    return failed == 0 ? 0 : 1;
}
#pragma once
#include "value.hpp"
#include <memory>
#include <string>
#include <unordered_map>

namespace vertox {

struct Env : std::enable_shared_from_this<Env> {
    std::unordered_map<std::string, ValuePtr> vars;
    std::shared_ptr<Env> parent;
    std::string name;  // debug uchun

    Env() = default;
    explicit Env(std::shared_ptr<Env> p, std::string n = "")
        : parent(std::move(p)), name(std::move(n)) {}

    // Qiymat olish (parent chain bo'ylab)
    ValuePtr get(const std::string& name);

    // Qiymat saqlash (mavjud bo'lsa - yangilash, yo'q bo'lsa - shu scope'da)
    void set(const std::string& name, ValuePtr v);

    // Yangi o'zgaruvchi shu scope'da
    void define(const std::string& name, ValuePtr v);

    // Bor-yo'qligini tekshirish
    bool has(const std::string& name) const;

    // Global scope'ni topish
    std::shared_ptr<Env> globalScope();
};

} // namespace vertox
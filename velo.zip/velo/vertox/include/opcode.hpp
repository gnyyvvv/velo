#pragma once
#include <cstdint>
#include <string>

namespace vertox {

enum class Op : uint8_t {
    PUSH, POP, DUP, SWAP,
    LOAD, STORE, DEFINE,
    PUSH_TRUE, PUSH_FALSE, PUSH_NULL, PUSH_INT,
    BUILD_LIST, BUILD_MAP, BUILD_TUPLE, INDEX, SET_INDEX,
    ADD, SUB, MUL, DIV, IDIV, MOD, POW, NEG,
    EQ, NEQ, LT, GT, LE, GE, IN, IS,
    NOT,
    JUMP, JUMP_IF_FALSE, JUMP_IF_TRUE,
    JUMP_IF_FALSE_KEEP, JUMP_IF_TRUE_KEEP, JUMP_IF_NULL,
    MAKE_FN, CALL, RETURN, RETURN_NULL,
    GET_ITER, ITER_NEXT, ITER_VALUE,
    NOP, HALT, PRINT, DEBUG,
    GET_ATTR,        // yangi: obj.attr
    CALL_METHOD      // yangi: obj.method()
};

inline const char* opName(Op op) {
    switch (op) {
        case Op::PUSH: return "PUSH";
        case Op::POP: return "POP";
        case Op::DUP: return "DUP";
        case Op::SWAP: return "SWAP";
        case Op::LOAD: return "LOAD";
        case Op::STORE: return "STORE";
        case Op::DEFINE: return "DEFINE";
        case Op::PUSH_TRUE: return "PUSH_TRUE";
        case Op::PUSH_FALSE: return "PUSH_FALSE";
        case Op::PUSH_NULL: return "PUSH_NULL";
        case Op::PUSH_INT: return "PUSH_INT";
        case Op::BUILD_LIST: return "BUILD_LIST";
        case Op::BUILD_MAP: return "BUILD_MAP";
        case Op::BUILD_TUPLE: return "BUILD_TUPLE";
        case Op::INDEX: return "INDEX";
        case Op::SET_INDEX: return "SET_INDEX";
        case Op::ADD: return "ADD";
        case Op::SUB: return "SUB";
        case Op::MUL: return "MUL";
        case Op::DIV: return "DIV";
        case Op::IDIV: return "IDIV";
        case Op::MOD: return "MOD";
        case Op::POW: return "POW";
        case Op::NEG: return "NEG";
        case Op::EQ: return "EQ";
        case Op::NEQ: return "NEQ";
        case Op::LT: return "LT";
        case Op::GT: return "GT";
        case Op::LE: return "LE";
        case Op::GE: return "GE";
        case Op::IN: return "IN";
        case Op::NOT: return "NOT";
        case Op::JUMP: return "JUMP";
        case Op::JUMP_IF_FALSE: return "JUMP_IF_FALSE";
        case Op::JUMP_IF_TRUE: return "JUMP_IF_TRUE";
        case Op::JUMP_IF_FALSE_KEEP: return "JUMP_IF_FALSE_KEEP";
        case Op::JUMP_IF_TRUE_KEEP: return "JUMP_IF_TRUE_KEEP";
        case Op::MAKE_FN: return "MAKE_FN";
        case Op::CALL: return "CALL";
        case Op::RETURN: return "RETURN";
        case Op::RETURN_NULL: return "RETURN_NULL";
        case Op::GET_ITER: return "GET_ITER";
        case Op::ITER_NEXT: return "ITER_NEXT";
        case Op::ITER_VALUE: return "ITER_VALUE";
        case Op::NOP: return "NOP";
        case Op::HALT: return "HALT";
        case Op::PRINT: return "PRINT";
        case Op::DEBUG: return "DEBUG";
        case Op::GET_ATTR: return "GET_ATTR";
        case Op::CALL_METHOD: return "CALL_METHOD";
        default: return "?";
    }
}

struct Instr {
    Op op;
    int64_t arg = 0;
    Instr() = default;
    Instr(Op o, int64_t a = 0) : op(o), arg(a) {}
};

} // namespace vertox
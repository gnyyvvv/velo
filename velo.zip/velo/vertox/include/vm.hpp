#pragma once
#include "opcode.hpp"
#include "env.hpp"
#include "value.hpp"
#include <vector>
#include <memory>

namespace vertox {

// RETURN signal - C++ exception orqali
struct ReturnSignal {
    ValuePtr value;
};

// Break/Continue signallari (kelajakda)
struct BreakSignal {};
struct ContinueSignal {};

// ============================================================
// Vertox Virtual Machine
// ============================================================
class VM {
public:
    VM();
    ~VM();

    // Global scope
    std::shared_ptr<Env> globals;

    // Asosiy metod: bytecode'ni ishga tushirish
    ValuePtr run(const std::vector<Instr>& code,
                 const std::vector<ValuePtr>& consts,
                 std::shared_ptr<Env> env = nullptr);

    // Debug rejimi (har bir ko'rsatmani chiqaradi)
    void setTrace(bool on) { trace_ = on; }

    // Statistikalar
    struct Stats {
        uint64_t instructions = 0;
        uint64_t calls = 0;
        double   time_ms = 0.0;
    };
    Stats stats() const { return stats_; }

    // Native funksiyani ro'yxatga olish
    void registerNative(const std::string& name, NativeFn fn);

private:
    bool trace_ = false;
    Stats stats_;

    void registerBuiltins();
};

} // namespace vertox
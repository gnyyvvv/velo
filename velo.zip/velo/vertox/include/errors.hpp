#pragma once
#include <stdexcept>
#include <string>

namespace vertox {

class VertoxError : public std::runtime_error {
public:
    int line, col;
    VertoxError(const std::string& msg, int l = 0, int c = 0)
        : std::runtime_error(format(msg, l, c)), line(l), col(c) {}
private:
    static std::string format(const std::string& m, int l, int c) {
        if (l == 0 && c == 0) return m;
        return "[" + std::to_string(l) + ":" + std::to_string(c) + "] " + m;
    }
};

class RuntimeError  : public VertoxError { using VertoxError::VertoxError; };
class CompileError  : public VertoxError { using VertoxError::VertoxError; };
class TypeError     : public VertoxError { using VertoxError::VertoxError; };
class IndexError    : public VertoxError { using VertoxError::VertoxError; };

} // namespace vertox
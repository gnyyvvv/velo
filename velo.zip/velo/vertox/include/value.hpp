#pragma once
#include "opcode.hpp"          // ? SHU QATOR QO'SHILDI
#include <memory>
#include <string>
#include <vector>
#include <unordered_map>
#include <functional>

namespace vertox {

struct Value;
struct Function;
struct Env;
struct Iterator;
struct Class;

using ValuePtr = std::shared_ptr<Value>;
using ListPtr  = std::shared_ptr<std::vector<ValuePtr>>;
using MapPtr   = std::shared_ptr<std::unordered_map<std::string, ValuePtr>>;
using TuplePtr = std::shared_ptr<std::vector<ValuePtr>>;
using FnPtr    = std::shared_ptr<Function>;
using IterPtr  = std::shared_ptr<Iterator>;
using ClassPtr = std::shared_ptr<Class>;

using NativeFn = ValuePtr(*)(std::vector<ValuePtr>&);

// ============================================================
// Value - har qanday qiymat
// ============================================================
struct Value {
    enum class Type : uint8_t {
        Null, Bool, Int, Float, Str,
        List, Map, Tuple, Fn, Native,
        Iterator, Class, Instance
    };

    Type type = Type::Null;

    bool        b = false;
    long long   i = 0;
    double      f = 0.0;
    std::string s;

    ListPtr   list;
    MapPtr    map;
    TuplePtr  tuple;
    FnPtr     fn;
    NativeFn  native = nullptr;
    IterPtr   iter;
    ClassPtr  cls;
    ValuePtr  instance_of;

    // === Konstruktorlar ===
    static ValuePtr null();
    static ValuePtr boolean(bool v);
    static ValuePtr integer(long long v);
    static ValuePtr floating(double v);
    static ValuePtr string(std::string v);
    static ValuePtr listOf(ListPtr l);
    static ValuePtr listOf(std::vector<ValuePtr> v);
    static ValuePtr mapOf(MapPtr m);
    static ValuePtr tupleOf(TuplePtr t);
    static ValuePtr func(FnPtr f);
    static ValuePtr nativeFunc(NativeFn f);
    static ValuePtr iterator(IterPtr it);
    static ValuePtr classObj(ClassPtr c);

    // === Yordamchi metodlar ===
    std::string toString() const;
    std::string repr() const;
    bool truthy() const;
    double toNumber() const;
    long long toInt() const;
    bool isNumber() const { return type == Type::Int || type == Type::Float; }

    // === Operatorlar ===
    static ValuePtr add(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr sub(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr mul(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr div(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr idiv(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr mod(const ValuePtr& a, const ValuePtr& b);
    static ValuePtr pow(const ValuePtr& a, const ValuePtr& b);

    static bool eq(const ValuePtr& a, const ValuePtr& b);
    static bool lt(const ValuePtr& a, const ValuePtr& b);
    static bool gt(const ValuePtr& a, const ValuePtr& b);
};

// ============================================================
// Function
// ============================================================
struct Function {
    std::string name;
    std::vector<std::string> params;
    std::vector<Instr> code;              // ? Endi Instr ma'lum
    std::vector<ValuePtr> consts;
    std::shared_ptr<Env> closure;
    bool is_generator = false;
};

// ============================================================
// Iterator
// ============================================================
struct Iterator {
    enum class Kind { List, Str, Map, Tuple, Range, Custom };  // ? Tuple qo'shildi
    Kind kind = Kind::List;                                    // ? default qiymat
    ValuePtr source;
    size_t index = 0;

    bool hasNext() const;
    ValuePtr next();
};

// ============================================================
// Class
// ============================================================
struct Class {
    std::string name;
    ClassPtr parent;
    std::unordered_map<std::string, ValuePtr> methods;
    std::unordered_map<std::string, ValuePtr> attrs;
};

} // namespace vertox
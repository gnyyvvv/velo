#include "include/vm.hpp"
#include "include/opcode.hpp"
#include "include/value.hpp"
#include <iostream>

using namespace vertox;

int main() {
    std::cout << "Vertox Engine v0.1\n";
    std::cout << "Bytecode'ni qo'lda yozib sinab ko'ramiz.\n\n";
    
    // Misol: (10 + 20) * 2 - 5 = 55
    std::vector<Instr> code = {
        {Op::PUSH_INT, 10},
        {Op::PUSH_INT, 20},
        {Op::ADD},              // 30
        {Op::PUSH_INT, 2},
        {Op::MUL},              // 60
        {Op::PUSH_INT, 5},
        {Op::SUB},              // 55
        {Op::HALT}
    };
    std::vector<ValuePtr> consts;
    
    VM vm;
    vm.setTrace(true);          // har bir ko'rsatmani ko'rish
    auto result = vm.run(code, consts);
    
    std::cout << "\nNatija: " << result->toString() << "\n";
    std::cout << "Ko'rsatmalar: " << vm.stats().instructions << "\n";
    std::cout << "Vaqt: " << vm.stats().time_ms << " ms\n";
    
    return 0;
}
// ============================================================
// Velo tili - CLI (Command Line Interface)
// ============================================================
// Foydalanish:
//   velo.exe                > REPL (interaktiv rejim)
//   velo.exe fayl.vl        > faylni ishga tushirish
//   velo.exe -v             > versiya
//   velo.exe -h             > yordam
//
// Muhim: "Enter bosing" yo'q � Python kabi professional.
// Fayl ustiga bosilganda terminal ochiq qolishi uchun
// `install_file_assoc.bat` da `cmd /k` ishlatiladi.
// ============================================================

#include "include/velo.hpp"
#include <iostream>
#include <string>

#ifdef _WIN32
    #include <direct.h>      // _chdir
    #include <windows.h>     // SetConsoleTitleA
#endif

// ============================================================
// ASCII Banner
// ============================================================
static const char* BANNER = R"(
 __   __  ___  _      ___
 \ \ / / | __|| |    / _ \
  \ V /  | _| | |__ | (_) |
   \_/   |___||____| \___/     v0.1
)";

// ============================================================
// REPL - interaktiv rejim
// ============================================================
static void repl() {
    std::cout << BANNER << "\n";
    std::cout << "Velo REPL v0.1\n";
    std::cout << "Chiqish: Ctrl+D yoki Ctrl+C\n\n";

    std::string line;
    while (true) {
        std::cout << "vl> ";
        std::cout.flush();

        if (!std::getline(std::cin, line)) {
            std::cout << "\n";
            break;
        }
        if (line.empty()) continue;

        velo::Velo::run(line, "<repl>");
    }
}

// ============================================================
// Yordam
// ============================================================
static void printHelp() {
    std::cout << BANNER << "\n";
    std::cout << "Ishlatish:\n";
    std::cout << "  velo              REPL (interaktiv rejim)\n";
    std::cout << "  velo fayl.vl      Faylni ishga tushirish\n";
    std::cout << "  velo -v           Versiyani ko'rsatish\n";
    std::cout << "  velo -h           Yordam\n";
    std::cout << "\n";
    std::cout << "Misollar:\n";
    std::cout << "  velo examples\\hello.vl\n";
    std::cout << "  velo examples\\fibonacci.vl\n";
}

// ============================================================
// Main
// ============================================================
int main(int argc, char** argv) {

    // ============================================================
    // QADAM 1: Fayl ustiga bosilganda ish papkasini o'zgartirish
    // ============================================================
    #ifdef _WIN32
    if (argc >= 2) {
        std::string path = argv[1];

        // Faqat fayl bo'lsa (flag emas)
        if (path != "-v" && path != "--version" &&
            path != "-h" && path != "--help") {

            size_t pos = path.find_last_of("\\/");
            if (pos != std::string::npos) {
                std::string dir = path.substr(0, pos);
                if (!dir.empty()) {
                    _chdir(dir.c_str());
                }
            }
        }
    }
    #endif

    // ============================================================
    // QADAM 2: Argumentlarni tahlil qilish
    // ============================================================
    int result = 0;

    if (argc < 2) {
        // Argument yo'q > REPL
        repl();
    }
    else {
        std::string arg = argv[1];

        if (arg == "--version" || arg == "-v") {
            std::cout << "Velo v0.1\n";
            std::cout << "Vertox Engine v0.1\n";
        }
        else if (arg == "--help" || arg == "-h") {
            printHelp();
        }
        else {
            // Fayl nomini olish (papka qismini olib tashlash)
            std::string filename = arg;

            #ifdef _WIN32
            size_t pos = filename.find_last_of("\\/");
            if (pos != std::string::npos) {
                filename = filename.substr(pos + 1);
            }
            #endif

            // Terminal sarlavhasini o'zgartirish
            #ifdef _WIN32
            std::string title = "Velo - " + filename;
            SetConsoleTitleA(title.c_str());
            #endif

            // Faylni ishga tushirish
            result = velo::Velo::runFile(filename);
        }
    }

    // ============================================================
    // ? "Enter bosing" YO'Q � professional tillar kabi
    // ============================================================
    // Terminal orqali: dastur tugaydi, terminal yopiladi (Python kabi)
    // Fayl ustiga bosish: `cmd /k` tufayli terminal ochiq qoladi
    // ============================================================

    return result;
}
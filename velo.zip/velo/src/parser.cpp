#include "../include/parser.hpp"
#include <stdexcept>
#include <iostream>

namespace velo {

// ============================================================
// Yordamchi funksiyalar
// ============================================================

Parser::Parser(std::vector<Token> tokens) : toks_(std::move(tokens)) {}

const Token& Parser::peek(int k) const {
    size_t j = pos_ + k;
    if (j >= toks_.size()) return toks_.back();
    return toks_[j];
}

const Token& Parser::prev() const {
    return toks_[pos_ - 1];
}

bool Parser::isAtEnd() const {
    return peek().type == TokType::EOF_;
}

bool Parser::check(TokType type, const std::string& text) const {
    const auto& t = peek();
    if (t.type != type) return false;
    if (!text.empty() && t.text != text) return false;
    return true;
}

bool Parser::checkKw(const std::string& kw) const {
    return check(TokType::KW, kw);
}

bool Parser::checkOp(const std::string& op) const {
    return check(TokType::OP, op);
}

bool Parser::match(TokType type, const std::string& text) {
    if (check(type, text)) {
        advance();
        return true;
    }
    return false;
}

bool Parser::matchKw(const std::string& kw) {
    if (checkKw(kw)) { advance(); return true; }
    return false;
}

bool Parser::matchOp(const std::string& op) {
    if (checkOp(op)) { advance(); return true; }
    return false;
}

const Token& Parser::advance() {
    if (!isAtEnd()) pos_++;
    return toks_[pos_ - 1];
}

const Token& Parser::expect(TokType type, const std::string& err) {
    if (!check(type)) {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) +
            ": " + (err.empty() ? "Kutilgan token" : err) +
            ", topildi: '" + t.text + "'"
        );
    }
    return advance();
}

const Token& Parser::expectOp(const std::string& op) {
    if (!checkOp(op)) {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) +
            ": kutilgan '" + op + "', topildi: '" + t.text + "'"
        );
    }
    return advance();
}

const Token& Parser::expectKw(const std::string& kw) {
    if (!checkKw(kw)) {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) +
            ": kutilgan '" + kw + "', topildi: '" + t.text + "'"
        );
    }
    return advance();
}

void Parser::skipNewlines() {
    while (check(TokType::NEWLINE)) advance();
}

void Parser::expectNewline() {
    if (check(TokType::NEWLINE)) {
        advance();
    } else if (!isAtEnd() && !check(TokType::DEDENT)) {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) +
            ": qator oxiri kutilgan"
        );
    }
}

void Parser::expectColon() {
    if (!matchOp(":")) {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) + ": ':' kutilgan"
        );
    }
}

// ============================================================
// DASTUR (Program)
// ============================================================

NodePtr Parser::parseProgram() {
    auto prog = std::make_unique<Program>();
    skipNewlines();

    while (!isAtEnd()) {
        prog->statements.push_back(statement());
        skipNewlines();
    }
    return prog;
}

// ============================================================
// KO'RSATMALAR (Statements)
// ============================================================

NodePtr Parser::statement() {
    if (check(TokType::KW)) {
        const auto& kw = peek().text;

        if (kw == "if")       return ifStatement();
        if (kw == "elif")     return ifStatement();   // ? elif ham qabul
        if (kw == "while")    return whileStatement();
        if (kw == "for")      return forStatement();
        if (kw == "def")      return defStatement();
        if (kw == "class")    return classStatement();
        if (kw == "return")   return returnStatement();
        if (kw == "break")    return breakStatement();
        if (kw == "continue") return continueStatement();
        if (kw == "pass")     return passStatement();
        if (kw == "import")   return importStatement();
        if (kw == "from")     return fromImportStatement();
    }
    return simpleStatement();
}

NodePtr Parser::simpleStatement() {
    NodePtr expr = expression();

    // Tayinlash: x = 5
    if (matchOp("=")) {
        NodePtr value = expression();
        auto asn = std::make_unique<Assign>();
        asn->target = std::move(expr);
        asn->value = std::move(value);
        if (check(TokType::NEWLINE)) advance();
        return asn;
    }

    // Qisqartirilgan: +=, -=, *=, /=, %=, **=, //=
    static const char* augOps[] = {"+=", "-=", "*=", "/=", "%=", "**=", "//="};
    for (auto op : augOps) {
        if (checkOp(op)) {
            advance();
            NodePtr value = expression();
            auto aug = std::make_unique<AugAssign>();
            aug->target = std::move(expr);
            aug->op = op;
            aug->value = std::move(value);
            if (check(TokType::NEWLINE)) advance();
            return aug;
        }
    }

    if (check(TokType::NEWLINE)) advance();
    return expr;
}

NodePtr Parser::compoundStatement() {
    return statement();
}

// ============================================================
// IF / ELIF / ELSE � TUZATILGAN
// ============================================================

NodePtr Parser::ifStatement() {
    // ? `if` YOKI `elif` qabul qilish
    if (checkKw("if")) {
        advance();
    } else if (checkKw("elif")) {
        advance();
    } else {
        const auto& t = peek();
        throw std::runtime_error(
            "Qator " + std::to_string(t.line) +
            ": kutilgan 'if' yoki 'elif', topildi: '" + t.text + "'"
        );
    }

    NodePtr cond = expression();
    expectColon();
    NodePtr thenBody = block();
    NodePtr elseBody = nullptr;

    skipNewlines();

    if (checkKw("elif")) {
        // ? `elif` ni rekursiv chaqirish
        elseBody = ifStatement();
    } else if (matchKw("else")) {
        expectColon();
        elseBody = block();
    }

    auto node = std::make_unique<If>();
    node->cond = std::move(cond);
    node->then_body = std::move(thenBody);
    node->else_body = std::move(elseBody);
    return node;
}

// ============================================================
// WHILE
// ============================================================

NodePtr Parser::whileStatement() {
    expectKw("while");
    NodePtr cond = expression();
    expectColon();
    NodePtr body = block();

    auto node = std::make_unique<While>();
    node->cond = std::move(cond);
    node->body = std::move(body);
    return node;
}

// ============================================================
// FOR
// ============================================================

NodePtr Parser::forStatement() {
    expectKw("for");
    const auto& varTok = expect(TokType::ID, "for uchun o'zgaruvchi");
    expectKw("in");
    NodePtr iter = expression();
    expectColon();
    NodePtr body = block();

    auto node = std::make_unique<For>();
    node->target = varTok.text;
    node->iter = std::move(iter);
    node->body = std::move(body);
    return node;
}

// ============================================================
// DEF (funksiya)
// ============================================================

NodePtr Parser::defStatement() {
    expectKw("def");
    const auto& nameTok = expect(TokType::ID, "funksiya nomi");
    expectOp("(");

    auto params = parseParamList();

    expectOp(")");
    expectColon();
    NodePtr body = block();

    auto node = std::make_unique<FnDef>();
    node->name = nameTok.text;
    node->params = std::move(params);
    node->body = std::move(body);
    return node;
}

std::vector<std::string> Parser::parseParamList() {
    std::vector<std::string> params;
    if (checkOp(")")) return params;

    params.push_back(expect(TokType::ID).text);
    while (matchOp(",")) {
        if (checkOp(")")) break;
        params.push_back(expect(TokType::ID).text);
    }
    return params;
}

// ============================================================
// RETURN / BREAK / CONTINUE / PASS
// ============================================================

NodePtr Parser::returnStatement() {
    expectKw("return");
    auto node = std::make_unique<Return>();
    if (!check(TokType::NEWLINE) && !check(TokType::DEDENT) && !isAtEnd()) {
        node->value = expression();
    }
    if (check(TokType::NEWLINE)) advance();
    return node;
}

NodePtr Parser::breakStatement() {
    expectKw("break");
    if (check(TokType::NEWLINE)) advance();
    return std::make_unique<Break>();
}

NodePtr Parser::continueStatement() {
    expectKw("continue");
    if (check(TokType::NEWLINE)) advance();
    return std::make_unique<Continue>();
}

NodePtr Parser::passStatement() {
    expectKw("pass");
    if (check(TokType::NEWLINE)) advance();
    return std::make_unique<Pass>();
}

// ============================================================
// IMPORT
// ============================================================

NodePtr Parser::importStatement() {
    expectKw("import");
    auto node = std::make_unique<Import>();
    node->names.push_back(expect(TokType::ID).text);
    while (matchOp(",")) {
        node->names.push_back(expect(TokType::ID).text);
    }
    if (check(TokType::NEWLINE)) advance();
    return node;
}

NodePtr Parser::fromImportStatement() {
    expectKw("from");
    std::string module = expect(TokType::ID).text;
    expectKw("import");

    auto node = std::make_unique<FromImport>();
    node->module = module;
    node->names.push_back(expect(TokType::ID).text);
    while (matchOp(",")) {
        node->names.push_back(expect(TokType::ID).text);
    }
    if (check(TokType::NEWLINE)) advance();
    return node;
}

// ============================================================
// CLASS
// ============================================================

NodePtr Parser::classStatement() {
    expectKw("class");
    std::string name = expect(TokType::ID).text;

    std::vector<std::string> bases;
    if (matchOp("(")) {
        if (!checkOp(")")) {
            bases.push_back(expect(TokType::ID).text);
            while (matchOp(",")) {
                if (checkOp(")")) break;
                bases.push_back(expect(TokType::ID).text);
            }
        }
        expectOp(")");
    }

    expectColon();
    NodePtr body = block();

    auto node = std::make_unique<ClassDef>();
    node->name = name;
    node->bases = std::move(bases);
    node->body = std::move(body);
    return node;
}

// ============================================================
// BLOK (INDENT ... DEDENT)
// ============================================================

NodePtr Parser::block() {
    auto blk = std::make_unique<Block>();

    if (check(TokType::NEWLINE)) advance();

    if (!check(TokType::INDENT)) {
        // Bir qatorda: if x: print(y)
        blk->statements.push_back(statement());
        return blk;
    }
    advance();   // INDENT

    skipNewlines();
    while (!check(TokType::DEDENT) && !isAtEnd()) {
        blk->statements.push_back(statement());
        skipNewlines();
    }

    if (check(TokType::DEDENT)) advance();

    return blk;
}

// ============================================================
// IFODALAR (Expressions)
// ============================================================

NodePtr Parser::expression() {
    return assignment();
}

NodePtr Parser::assignment() {
    NodePtr left = ternary();

    if (checkOp("=")) {
        advance();
        NodePtr value = assignment();
        auto node = std::make_unique<Assign>();
        node->target = std::move(left);
        node->value = std::move(value);
        return node;
    }
    return left;
}

NodePtr Parser::ternary() {
    NodePtr cond = orExpr();

    if (matchKw("if")) {
        NodePtr thenVal = orExpr();
        expectKw("else");
        NodePtr elseVal = ternary();

        auto node = std::make_unique<If>();
        node->cond = std::move(cond);
        node->then_body = std::move(thenVal);
        node->else_body = std::move(elseVal);
        return node;
    }
    return cond;
}

NodePtr Parser::orExpr() {
    NodePtr left = andExpr();
    while (matchKw("or") || matchOp("||")) {
        NodePtr right = andExpr();
        auto node = std::make_unique<BinOp>();
        node->op = "or";
        node->left = std::move(left);
        node->right = std::move(right);
        left = std::move(node);
    }
    return left;
}

NodePtr Parser::andExpr() {
    NodePtr left = notExpr();
    while (matchKw("and") || matchOp("&&")) {
        NodePtr right = notExpr();
        auto node = std::make_unique<BinOp>();
        node->op = "and";
        node->left = std::move(left);
        node->right = std::move(right);
        left = std::move(node);
    }
    return left;
}

NodePtr Parser::notExpr() {
    if (matchKw("not")) {
        auto node = std::make_unique<UnOp>();
        node->op = "not";
        node->operand = notExpr();
        return node;
    }
    return comparison();
}

NodePtr Parser::comparison() {
    NodePtr left = arith();

    static const char* cmpOps[] = {"==", "!=", "<", ">", "<=", ">="};
    bool found = false;
    auto cmp = std::make_unique<Compare>();
    cmp->left = std::move(left);

    for (auto op : cmpOps) {
        if (checkOp(op)) {
            advance();
            cmp->ops.push_back({op, arith()});
            found = true;
            break;
        }
    }

    if (matchKw("in")) {
        cmp->ops.push_back({"in", arith()});
        found = true;
    }
    if (checkKw("not")) {
        advance();
        if (matchKw("in")) {
            cmp->ops.push_back({"not in", arith()});
            found = true;
        }
    }
    if (matchKw("is")) {
        cmp->ops.push_back({"is", arith()});
        found = true;
    }

    if (!found) {
        return std::move(cmp->left);
    }
    return cmp;
}

NodePtr Parser::arith() {
    NodePtr left = term();
    while (checkOp("+") || checkOp("-")) {
        std::string op = advance().text;
        NodePtr right = term();
        auto node = std::make_unique<BinOp>();
        node->op = op;
        node->left = std::move(left);
        node->right = std::move(right);
        left = std::move(node);
    }
    return left;
}

NodePtr Parser::term() {
    NodePtr left = factor();
    while (checkOp("*") || checkOp("/") || checkOp("%") || checkOp("//")) {
        std::string op = advance().text;
        NodePtr right = factor();
        auto node = std::make_unique<BinOp>();
        node->op = op;
        node->left = std::move(left);
        node->right = std::move(right);
        left = std::move(node);
    }
    return left;
}

NodePtr Parser::factor() {
    if (checkOp("-") || checkOp("+")) {
        std::string op = advance().text;
        auto node = std::make_unique<UnOp>();
        node->op = op;
        node->operand = factor();
        return node;
    }
    return power();
}

NodePtr Parser::power() {
    NodePtr base = unary();
    if (checkOp("**")) {
        advance();
        NodePtr exp = unary();
        auto node = std::make_unique<BinOp>();
        node->op = "**";
        node->left = std::move(base);
        node->right = std::move(exp);
        return node;
    }
    return base;
}

NodePtr Parser::unary() {
    if (checkOp("-") || checkOp("+")) {
        std::string op = advance().text;
        auto node = std::make_unique<UnOp>();
        node->op = op;
        node->operand = unary();
        return node;
    }
    return postfix();
}

NodePtr Parser::postfix() {
    NodePtr node = atom();

    while (true) {
        if (matchOp("(")) {
            node = parseArgs(std::move(node));
            continue;
        }
        if (matchOp("[")) {
            NodePtr idx = expression();
            expectOp("]");
            auto n = std::make_unique<Index>();
            n->obj = std::move(node);
            n->index = std::move(idx);
            node = std::move(n);
            continue;
        }
        if (matchOp(".")) {
            const auto& attr = expect(TokType::ID, "xossa nomi");
            auto n = std::make_unique<Attribute>();
            n->obj = std::move(node);
            n->attr = attr.text;
            node = std::move(n);
            continue;
        }
        break;
    }
    return node;
}

NodePtr Parser::parseArgs(NodePtr fn) {
    auto call = std::make_unique<Call>();
    call->fn = std::move(fn);

    if (!checkOp(")")) {
        call->args.push_back(expression());
        while (matchOp(",")) {
            if (checkOp(")")) break;
            call->args.push_back(expression());
        }
    }
    expectOp(")");
    return call;
}

NodePtr Parser::atom() {
    const auto& t = peek();

    // Son
    if (t.type == TokType::INT) {
        advance();
        auto n = std::make_unique<Num>();
        n->i = t.i;
        n->isFloat = false;
        return n;
    }
    if (t.type == TokType::FLOAT) {
        advance();
        auto n = std::make_unique<Num>();
        n->f = t.f;
        n->isFloat = true;
        return n;
    }

    // String
    if (t.type == TokType::STR) {
        advance();
        auto s = std::make_unique<Str>();
        s->value = t.text;
        return s;
    }
    if (t.type == TokType::FSTR) {
        advance();
        auto s = std::make_unique<FStr>();
        s->value = t.text;
        return s;
    }

    // True / False / None
    if (checkKw("True"))  { advance(); auto b = std::make_unique<Bool>(); b->value = true;  return b; }
    if (checkKw("False")) { advance(); auto b = std::make_unique<Bool>(); b->value = false; return b; }
    if (checkKw("None"))  { advance(); return std::make_unique<Null>(); }

    // Lambda
    if (matchKw("lambda")) {
        auto lam = std::make_unique<Lambda>();
        if (!checkOp(":")) {
            lam->params.push_back(expect(TokType::ID).text);
            while (matchOp(",")) {
                lam->params.push_back(expect(TokType::ID).text);
            }
        }
        expectColon();
        lam->body = expression();
        return lam;
    }

    // Identifikator
    if (t.type == TokType::ID) {
        advance();
        auto v = std::make_unique<Var>();
        v->name = t.text;
        return v;
    }

    // Qavs: (expr)
    if (matchOp("(")) {
        if (checkOp(")")) {
            advance();
            return std::make_unique<TupleLit>();
        }

        NodePtr first = expression();

        if (checkOp(",")) {
            auto tup = std::make_unique<TupleLit>();
            tup->items.push_back(std::move(first));
            while (matchOp(",")) {
                if (checkOp(")")) break;
                tup->items.push_back(expression());
            }
            expectOp(")");
            return tup;
        }

        expectOp(")");
        return first;
    }

    // List: [a, b, c]
    if (matchOp("[")) {
        auto lst = std::make_unique<ListLit>();
        if (!checkOp("]")) {
            lst->items.push_back(expression());
            while (matchOp(",")) {
                if (checkOp("]")) break;
                lst->items.push_back(expression());
            }
        }
        expectOp("]");
        return lst;
    }

    // Dict: {k: v, ...}
    if (matchOp("{")) {
        auto dict = std::make_unique<DictLit>();
        if (!checkOp("}")) {
            NodePtr key = expression();
            expectOp(":");
            NodePtr val = expression();
            dict->items.push_back({std::move(key), std::move(val)});
            while (matchOp(",")) {
                if (checkOp("}")) break;
                NodePtr k = expression();
                expectOp(":");
                NodePtr v = expression();
                dict->items.push_back({std::move(k), std::move(v)});
            }
        }
        expectOp("}");
        return dict;
    }

    throw std::runtime_error(
        "Qator " + std::to_string(t.line) +
        ": kutilmagan token: '" + t.text + "'"
    );
}

} // namespace velo
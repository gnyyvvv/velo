#include "../include/lexer.hpp"
#include <unordered_set>
#include <cctype>
#include <stdexcept>

namespace velo {

// Python kalit so'zlari
static const std::unordered_set<std::string> KEYWORDS = {
    "if", "elif", "else",
    "for", "in", "while", "break", "continue",
    "pass", "return", "yield",
    "def", "class", "lambda",
    "self", "super", "new",
    "and", "or", "not", "is",
    "True", "False", "None",
    "try", "except", "finally", "raise",
    "with", "as",
    "import", "from", "global", "nonlocal",
    "async", "await",
    "assert", "del"
};

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> out;
    indentStack_.push_back(0);

    while (i_ < src_.size()) {

        // QATOR BOSHI: indentatsiya
        if (atLineStart_ && bracketDepth_ == 0) {
            int spaces = 0;
            size_t j = i_;
            while (j < src_.size() && (src_[j] == ' ' || src_[j] == '\t')) {
                if (src_[j] == '\t') spaces += 4;
                else spaces += 1;
                j++;
            }

            if (j < src_.size() && src_[j] != '\n' && src_[j] != '#') {
                handleIndent(out, spaces);
            }

            while (i_ < src_.size() && (src_[i_] == ' ' || src_[i_] == '\t'))
                adv();

            atLineStart_ = false;
        }

        if (i_ >= src_.size()) break;

        char c = peek();

        // Bo'sh joy
        if (c == ' ' || c == '\t' || c == '\r') {
            adv();
            continue;
        }

        // Komment
        if (c == '#') {
            while (i_ < src_.size() && peek() != '\n') adv();
            continue;
        }

        // Yangi qator
        if (c == '\n') {
            adv();
            if (bracketDepth_ == 0) {
                out.emplace_back(TokType::NEWLINE, "\n", line_, col_);
                atLineStart_ = true;
            }
            continue;
        }

        int startLine = line_, startCol = col_;

        // Raqamlar
        if (std::isdigit((unsigned char)c)) {
            std::string n;
            while (std::isdigit((unsigned char)peek())) n += adv();
            if (peek() == '.' && std::isdigit((unsigned char)peek(1))) {
                n += adv();
                while (std::isdigit((unsigned char)peek())) n += adv();
                Token t(TokType::FLOAT, n, startLine, startCol);
                t.f = std::stod(n);
                out.push_back(std::move(t));
            } else {
                Token t(TokType::INT, n, startLine, startCol);
                t.i = std::stoll(n);
                out.push_back(std::move(t));
            }
            continue;
        }

        // Identifikator yoki kalit so'z
        if (std::isalpha((unsigned char)c) || c == '_') {
            std::string n;
            while (std::isalnum((unsigned char)peek()) || peek() == '_')
                n += adv();

            // f-string
            if (n == "f" && (peek() == '"' || peek() == '\'')) {
                char q = adv();
                std::string s;
                while (peek() != q && i_ < src_.size()) {
                    if (peek() == '\\') {
                        adv();
                        char e = adv();
                        if (e == 'n') s += '\n';
                        else if (e == 't') s += '\t';
                        else s += e;
                    } else s += adv();
                }
                adv();
                out.emplace_back(TokType::FSTR, s, startLine, startCol);
                continue;
            }

            if (KEYWORDS.count(n)) {
                out.emplace_back(TokType::KW, n, startLine, startCol);
            } else {
                out.emplace_back(TokType::ID, n, startLine, startCol);
            }
            continue;
        }

        // Stringlar
        if (c == '"' || c == '\'') {
            char q = adv();
            std::string s;
            while (peek() != q && i_ < src_.size()) {
                if (peek() == '\\') {
                    adv();
                    char e = adv();
                    switch (e) {
                        case 'n': s += '\n'; break;
                        case 't': s += '\t'; break;
                        case 'r': s += '\r'; break;
                        case '\\': s += '\\'; break;
                        case '"': s += '"'; break;
                        case '\'': s += '\''; break;
                        default: s += e;
                    }
                } else s += adv();
            }
            if (peek() != q) throw std::runtime_error("Yopilmagan string");
            adv();
            out.emplace_back(TokType::STR, s, startLine, startCol);
            continue;
        }

        // Qavslar
        if (c == '(' || c == '[' || c == '{') {
            bracketDepth_++;
            adv();
            out.emplace_back(TokType::OP, std::string(1, c), startLine, startCol);
            continue;
        }
        if (c == ')' || c == ']' || c == '}') {
            if (bracketDepth_ > 0) bracketDepth_--;
            adv();
            out.emplace_back(TokType::OP, std::string(1, c), startLine, startCol);
            continue;
        }

        // Ko'p belgili operatorlar
        static const char* ops3[] = {"**=", "//=", "..."};
        static const char* ops2[] = {
            "==", "!=", "<=", ">=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "**",
            "//", "->", ":="
        };

        bool matched = false;

        for (auto op : ops3) {
            if (src_.compare(i_, 3, op) == 0) {
                adv(); adv(); adv();
                out.emplace_back(TokType::OP, op, startLine, startCol);
                matched = true;
                break;
            }
        }
        if (matched) continue;

        for (auto op : ops2) {
            if (src_.compare(i_, 2, op) == 0) {
                adv(); adv();
                out.emplace_back(TokType::OP, op, startLine, startCol);
                matched = true;
                break;
            }
        }
        if (matched) continue;

        // Bir belgili
        if (std::string("+-*/%<>=!&|(){}[],:.;").find(c) != std::string::npos) {
            adv();
            out.emplace_back(TokType::OP, std::string(1, c), startLine, startCol);
            continue;
        }

        throw std::runtime_error(
            std::string("Kutilmagan belgi: '") + c + "' qator " +
            std::to_string(line_)
        );
    }

    // Fayl oxirida DEDENT'lar
    if (!atLineStart_) {
        out.emplace_back(TokType::NEWLINE, "\n", line_, col_);
    }
    while (indentStack_.size() > 1) {
        indentStack_.pop_back();
        out.emplace_back(TokType::DEDENT, "", line_, col_);
    }

    out.emplace_back(TokType::EOF_, "", line_, col_);
    return out;
}

void Lexer::handleIndent(std::vector<Token>& out, int currentIndent) {
    int top = indentStack_.back();

    if (currentIndent > top) {
        indentStack_.push_back(currentIndent);
        out.emplace_back(TokType::INDENT, "", line_, col_);
    } else if (currentIndent < top) {
        while (indentStack_.size() > 1 && indentStack_.back() > currentIndent) {
            indentStack_.pop_back();
            out.emplace_back(TokType::DEDENT, "", line_, col_);
        }
        if (indentStack_.back() != currentIndent) {
            throw std::runtime_error("Noto'g'ri indentatsiya (qator " +
                                     std::to_string(line_) + ")");
        }
    }
}

} // namespace velo
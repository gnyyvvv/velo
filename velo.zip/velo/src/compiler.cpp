#include "../include/compiler.hpp"
#include "../vertox/include/errors.hpp"
#include <stdexcept>
#include <iostream>

namespace velo {

using namespace vertox;

Compiler::Compiler() {}

CompiledCode Compiler::compile(Node* program) {
    visit(program);
    emit(Op::HALT);
    return { std::move(code_), std::move(consts_) };
}

int Compiler::constIdx(ValuePtr v) {
    consts_.push_back(v);
    return (int)consts_.size() - 1;
}

int Compiler::nameIdx(const std::string& name) {
    auto it = nameCache_.find(name);
    if (it != nameCache_.end()) return it->second;
    int idx = constIdx(Value::string(name));
    nameCache_[name] = idx;
    return idx;
}

void Compiler::emit(Op op, int64_t arg) {
    code_.emplace_back(op, arg);
}

void Compiler::patch(int pos, int target) {
    code_[pos].arg = target;
}

// ============================================================
// Asosiy visit dispatcher
// ============================================================
void Compiler::visit(Node* n) {
    if (!n) return;

    if (auto p = dynamic_cast<Program*>(n))       return visitProgram(p);
    if (auto p = dynamic_cast<Block*>(n))         return visitBlock(p);
    if (auto p = dynamic_cast<FnDef*>(n))         return visitFnDef(p);
    if (auto p = dynamic_cast<If*>(n))            return visitIf(p);
    if (auto p = dynamic_cast<While*>(n))         return visitWhile(p);
    if (auto p = dynamic_cast<For*>(n))           return visitFor(p);
    if (auto p = dynamic_cast<Return*>(n))        return visitReturn(p);
    if (auto p = dynamic_cast<Assign*>(n))        return visitAssign(p);
    if (auto p = dynamic_cast<AugAssign*>(n))     return visitAugAssign(p);
    if (auto p = dynamic_cast<Break*>(n))         return visitBreak(p);
    if (auto p = dynamic_cast<Continue*>(n))      return visitContinue(p);
    if (auto p = dynamic_cast<Pass*>(n))          return visitPass(p);

    expr(n);
    emit(Op::POP);
}

void Compiler::visitProgram(Program* n) {
    for (auto& s : n->statements) visit(s.get());
}

void Compiler::visitBlock(Block* n) {
    for (auto& s : n->statements) visit(s.get());
}

// ============================================================
// FnDef - funksiya
// ============================================================
void Compiler::visitFnDef(FnDef* n) {
    Compiler sub;
    sub.inFunction_ = true;
    sub.visit(n->body.get());
    sub.emit(Op::RETURN_NULL);

    auto fn = std::make_shared<Function>();
    fn->name = n->name;
    fn->params = n->params;
    fn->code = std::move(sub.code_);
    fn->consts = std::move(sub.consts_);

    int idx = constIdx(Value::func(fn));
    emit(Op::MAKE_FN, idx);
    emit(Op::DEFINE, nameIdx(n->name));
}

// ============================================================
// If - shartli
// ============================================================
void Compiler::visitIf(If* n) {
    expr(n->cond.get());
    emit(Op::JUMP_IF_FALSE, 0);
    int jumpFalse = here() - 1;

    visit(n->then_body.get());

    if (n->else_body) {
        emit(Op::JUMP, 0);
        int jumpEnd = here() - 1;
        patch(jumpFalse, here());
        visit(n->else_body.get());
        patch(jumpEnd, here());
    } else {
        patch(jumpFalse, here());
    }
}

// ============================================================
// While - tsikl
// ============================================================
void Compiler::visitWhile(While* n) {
    int loopStart = here();
    expr(n->cond.get());
    emit(Op::JUMP_IF_FALSE, 0);
    int jumpEnd = here() - 1;

    loopStack_.push_back({});
    visit(n->body.get());

    emit(Op::JUMP, loopStart);
    int loopEnd = here();

    patch(jumpEnd, loopEnd);

    auto& ctx = loopStack_.back();
    for (int p : ctx.breakPatches)    patch(p, loopEnd);
    for (int p : ctx.continuePatches) patch(p, loopStart);
    loopStack_.pop_back();
}

// ============================================================
// For - tsikl
// ============================================================
void Compiler::visitFor(For* n) {
    expr(n->iter.get());
    emit(Op::GET_ITER);
    int iterVarIdx = constIdx(Value::string("$__iter__"));
    emit(Op::DEFINE, iterVarIdx);

    int loopStart = here();

    emit(Op::LOAD, iterVarIdx);
    emit(Op::ITER_NEXT, 0);
    int jumpEnd = here() - 1;

    emit(Op::LOAD, iterVarIdx);
    emit(Op::ITER_VALUE);
    emit(Op::DEFINE, nameIdx(n->target));

    loopStack_.push_back({});
    visit(n->body.get());

    emit(Op::JUMP, loopStart);
    int loopEnd = here();

    patch(jumpEnd, loopEnd);
    emit(Op::POP);

    auto& ctx = loopStack_.back();
    for (int p : ctx.breakPatches)    patch(p, loopEnd);
    for (int p : ctx.continuePatches) patch(p, loopStart);
    loopStack_.pop_back();
}

// ============================================================
// Return / Break / Continue / Pass
// ============================================================
void Compiler::visitReturn(Return* n) {
    if (n->value) {
        expr(n->value.get());
        emit(Op::RETURN);
    } else {
        emit(Op::RETURN_NULL);
    }
}

void Compiler::visitBreak(Break*) {
    if (loopStack_.empty()) throw std::runtime_error("break tsikldan tashqarida");
    emit(Op::JUMP, 0);
    loopStack_.back().breakPatches.push_back(here() - 1);
}

void Compiler::visitContinue(Continue*) {
    if (loopStack_.empty()) throw std::runtime_error("continue tsikldan tashqarida");
    emit(Op::JUMP, 0);
    loopStack_.back().continuePatches.push_back(here() - 1);
}

void Compiler::visitPass(Pass*) {
    emit(Op::NOP);
}

// ============================================================
// Assign - tayinlash
// ============================================================
void Compiler::visitAssign(Assign* n) {
    expr(n->value.get());

    if (auto v = dynamic_cast<Var*>(n->target.get())) {
        emit(Op::DEFINE, nameIdx(v->name));
    }
    else if (auto idx = dynamic_cast<Index*>(n->target.get())) {
        throw std::runtime_error("Index tayinlash hozircha qo'llab-quvvatlanmaydi");
    }
    else {
        throw std::runtime_error("Noto'g'ri tayinlash maqsadi");
    }
}

void Compiler::visitAugAssign(AugAssign* n) {
    auto v = dynamic_cast<Var*>(n->target.get());
    if (!v) throw std::runtime_error("AugAssign faqat o'zgaruvchi uchun");

    int nameI = nameIdx(v->name);

    emit(Op::LOAD, nameI);
    expr(n->value.get());

    const std::string& op = n->op;
    if      (op == "+=")  emit(Op::ADD);
    else if (op == "-=")  emit(Op::SUB);
    else if (op == "*=")  emit(Op::MUL);
    else if (op == "/=")  emit(Op::DIV);
    else if (op == "%=")  emit(Op::MOD);
    else if (op == "**=") emit(Op::POW);
    else if (op == "//=") emit(Op::IDIV);
    else throw std::runtime_error("Noma'lum operator: " + op);

    emit(Op::STORE, nameI);
}

// ============================================================
// IFODALAR (Expressions)
// ============================================================
void Compiler::expr(Node* n) {
    if (!n) return;

    if (auto p = dynamic_cast<Num*>(n))       return exprNum(p);
    if (auto p = dynamic_cast<Str*>(n))       return exprStr(p);
    if (auto p = dynamic_cast<FStr*>(n))      return exprFStr(p);
    if (auto p = dynamic_cast<Bool*>(n))      return exprBool(p);
    if (auto p = dynamic_cast<Null*>(n))      return exprNull(p);
    if (auto p = dynamic_cast<Var*>(n))       return exprVar(p);
    if (auto p = dynamic_cast<BinOp*>(n))     return exprBinOp(p);
    if (auto p = dynamic_cast<UnOp*>(n))      return exprUnOp(p);
    if (auto p = dynamic_cast<Compare*>(n))   return exprCompare(p);
    if (auto p = dynamic_cast<Call*>(n))      return exprCall(p);
    if (auto p = dynamic_cast<ListLit*>(n))   return exprList(p);
    if (auto p = dynamic_cast<TupleLit*>(n))  return exprTuple(p);
    if (auto p = dynamic_cast<DictLit*>(n))   return exprDict(p);
    if (auto p = dynamic_cast<Index*>(n))     return exprIndex(p);
    if (auto p = dynamic_cast<Lambda*>(n))    return exprLambda(p);
    if (auto p = dynamic_cast<Attribute*>(n)) return exprAttribute(p);

    throw std::runtime_error("Kompilyatsiya qilib bo'lmaydigan ifoda");
}

void Compiler::exprNum(Num* n) {
    if (n->isFloat) {
        emit(Op::PUSH, constIdx(Value::floating(n->f)));
    } else {
        emit(Op::PUSH_INT, n->i);
    }
}

void Compiler::exprStr(Str* n) {
    emit(Op::PUSH, constIdx(Value::string(n->value)));
}

void Compiler::exprFStr(FStr* n) {
    emit(Op::PUSH, constIdx(Value::string(n->value)));
}

void Compiler::exprBool(Bool* n) {
    emit(n->value ? Op::PUSH_TRUE : Op::PUSH_FALSE);
}

void Compiler::exprNull(Null*) {
    emit(Op::PUSH_NULL);
}

void Compiler::exprVar(Var* n) {
    emit(Op::LOAD, nameIdx(n->name));
}

void Compiler::exprAttribute(Attribute* n) {
    expr(n->obj.get());
    int nameI = constIdx(Value::string(n->attr));
    emit(Op::GET_ATTR, nameI);
}

void Compiler::exprBinOp(BinOp* n) {
    if (n->op == "and") {
        expr(n->left.get());
        emit(Op::JUMP_IF_FALSE_KEEP, 0);
        int j = here() - 1;
        expr(n->right.get());
        patch(j, here());
        return;
    }
    if (n->op == "or") {
        expr(n->left.get());
        emit(Op::JUMP_IF_TRUE_KEEP, 0);
        int j = here() - 1;
        expr(n->right.get());
        patch(j, here());
        return;
    }

    expr(n->left.get());
    expr(n->right.get());

    if      (n->op == "+")  emit(Op::ADD);
    else if (n->op == "-")  emit(Op::SUB);
    else if (n->op == "*")  emit(Op::MUL);
    else if (n->op == "/")  emit(Op::DIV);
    else if (n->op == "//") emit(Op::IDIV);
    else if (n->op == "%")  emit(Op::MOD);
    else if (n->op == "**") emit(Op::POW);
    else throw std::runtime_error("Noma'lum operator: " + n->op);
}

void Compiler::exprUnOp(UnOp* n) {
    expr(n->operand.get());
    if      (n->op == "-")   emit(Op::NEG);
    else if (n->op == "+")   { /* hech narsa */ }
    else if (n->op == "not") emit(Op::NOT);
    else throw std::runtime_error("Noma'lum unar operator: " + n->op);
}

void Compiler::exprCompare(Compare* n) {
    if (n->ops.empty()) {
        expr(n->left.get());
        return;
    }

    expr(n->left.get());

    for (size_t i = 0; i < n->ops.size(); ++i) {
        const auto& entry = n->ops[i];
        const std::string& op = entry.first;
        Node* rightNode = entry.second.get();

        expr(rightNode);

        if      (op == "==")     emit(Op::EQ);
        else if (op == "!=")     emit(Op::NEQ);
        else if (op == "<")      emit(Op::LT);
        else if (op == ">")      emit(Op::GT);
        else if (op == "<=")     emit(Op::LE);
        else if (op == ">=")     emit(Op::GE);
        else if (op == "in")     emit(Op::IN);
        else if (op == "not in") { emit(Op::IN); emit(Op::NOT); }
        else if (op == "is")     emit(Op::EQ);
        else throw std::runtime_error("Noma'lum taqqoslash: " + op);
    }
}

void Compiler::exprCall(Call* n) {
    // Metod chaqiruv: obj.method(args)
    if (auto attr = dynamic_cast<Attribute*>(n->fn.get())) {
        for (auto& a : n->args) expr(a.get());
        expr(attr->obj.get());
        int nameI = constIdx(Value::string(attr->attr));
        emit(Op::GET_ATTR, nameI);
        emit(Op::CALL_METHOD, (int)n->args.size());
        return;
    }

    // Oddiy funksiya chaqiruv
    for (auto& a : n->args) expr(a.get());
    expr(n->fn.get());
    emit(Op::CALL, (int)n->args.size());
}

void Compiler::exprList(ListLit* n) {
    for (auto& it : n->items) expr(it.get());
    emit(Op::BUILD_LIST, (int)n->items.size());
}

void Compiler::exprTuple(TupleLit* n) {
    for (auto& it : n->items) expr(it.get());
    emit(Op::BUILD_TUPLE, (int)n->items.size());
}

void Compiler::exprDict(DictLit* n) {
    for (auto& kv : n->items) {
        expr(kv.first.get());
        expr(kv.second.get());
    }
    emit(Op::BUILD_MAP, (int)n->items.size());
}

void Compiler::exprIndex(Index* n) {
    expr(n->obj.get());
    expr(n->index.get());
    emit(Op::INDEX);
}

void Compiler::exprLambda(Lambda* n) {
    Compiler sub;
    sub.inFunction_ = true;
    sub.expr(n->body.get());
    sub.emit(Op::RETURN);

    auto fn = std::make_shared<Function>();
    fn->name = "<lambda>";
    fn->params = n->params;
    fn->code = std::move(sub.code_);
    fn->consts = std::move(sub.consts_);

    int idx = constIdx(Value::func(fn));
    emit(Op::MAKE_FN, idx);
}

} // namespace velo
#include "../include/velo.hpp"
#include "../include/lexer.hpp"
#include "../include/parser.hpp"
#include "../include/compiler.hpp"
#include "../vertox/include/vm.hpp"
#include <fstream>
#include <sstream>
#include <iostream>

namespace velo {

int Velo::run(const std::string& source, const std::string& filename) {
    try {
        // 1. Lexer
        Lexer lexer(source);
        auto tokens = lexer.tokenize();

        // 2. Parser
        Parser parser(std::move(tokens));
        auto ast = parser.parseProgram();

        // 3. Compiler
        Compiler compiler;
        auto compiled = compiler.compile(ast.get());

        // 4. VM
        vertox::VM vm;
        vm.run(compiled.code, compiled.consts);

        return 0;
    } catch (std::exception& e) {
        std::cerr << "Xato (" << filename << "): " << e.what() << "\n";
        return 1;
    }
}

int Velo::runFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "Xato: fayl ochilmadi: " << path << "\n";
        return 1;
    }

    std::stringstream buf;
    buf << file.rdbuf();
    return run(buf.str(), path);
}

} // namespace velo